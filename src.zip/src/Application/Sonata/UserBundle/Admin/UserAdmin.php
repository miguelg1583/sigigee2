<?php

namespace Application\Sonata\UserBundle\Admin;

use Sonata\UserBundle\Admin\Model\UserAdmin as BaseUserAdmin;

//use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;

class UserAdmin extends BaseUserAdmin
{
    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('username')
            ->add('usernameCanonical')
            ->add('email')
            ->add('emailCanonical')
            ->add('enabled')
            ->add('salt')
            ->add('password')
            ->add('lastLogin')
            ->add('locked')
            ->add('expired')
            ->add('expiresAt')
            ->add('confirmationToken')
            ->add('passwordRequestedAt')
            ->add('roles')
            ->add('credentialsExpired')
            ->add('credentialsExpireAt')
            ->add('createdAt')
            ->add('updatedAt')
            ->add('dateOfBirth')
            ->add('firstname')
            ->add('lastname')
            ->add('website')
            ->add('biography')
            ->add('gender')
            ->add('locale')
            ->add('timezone')
            ->add('phone')
            ->add('facebookUid')
            ->add('facebookName')
            ->add('facebookData')
            ->add('twitterUid')
            ->add('twitterName')
            ->add('twitterData')
            ->add('gplusUid')
            ->add('gplusName')
            ->add('gplusData')
            ->add('token')
            ->add('twoStepVerificationCode')
            ->add('id')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->addIdentifier('username')
//            ->add('usernameCanonical')
            ->add('email')
//            ->add('emailCanonical')
            ->add('enabled', null, array('editable'=>true))
//            ->add('salt')
//            ->add('password')
//            ->add('lastLogin')
            ->add('locked', null, array('editable'=>true))
//            ->add('expired')
//            ->add('expiresAt')
//            ->add('confirmationToken')
//            ->add('passwordRequestedAt')
//            ->add('roles')
//            ->add('credentialsExpired')
//            ->add('credentialsExpireAt')
//            ->add('createdAt')
//            ->add('updatedAt')
//            ->add('dateOfBirth')
//            ->add('firstname')
//            ->add('lastname')
//            ->add('website')
//            ->add('biography')
//            ->add('gender')
//            ->add('locale')
//            ->add('timezone')
//            ->add('phone')
//            ->add('facebookUid')
//            ->add('facebookName')
//            ->add('facebookData')
//            ->add('twitterUid')
//            ->add('twitterName')
//            ->add('twitterData')
//            ->add('gplusUid')
//            ->add('gplusName')
//            ->add('gplusData')
//            ->add('token')
//            ->add('twoStepVerificationCode')
//            ->add('id')
            ->add('_action', 'Acciones', array(
                'actions' => array(
                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                ),
                'label'=>'Acciones'));
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('username')
//                ->add('usernameCanonical')
                ->add('email')
//                ->add('emailCanonical')
//                ->add('enabled')
//                ->add('salt')
                ->add('password')
//                ->add('lastLogin')
//                ->add('locked')
//                ->add('expired')
//                ->add('expiresAt')
//                ->add('confirmationToken')
//                ->add('passwordRequestedAt')
//                ->add('roles')
//                ->add('credentialsExpired')
//                ->add('credentialsExpireAt')
//                ->add('createdAt')
//                ->add('updatedAt')
//                ->add('dateOfBirth')
//                ->add('firstname')
//                ->add('lastname')
//                ->add('website')
//                ->add('biography')
//                ->add('gender')
//                ->add('locale')
//                ->add('timezone')
//                ->add('phone')
//                ->add('facebookUid')
//                ->add('facebookName')
//                ->add('facebookData')
//                ->add('twitterUid')
//                ->add('twitterName')
//                ->add('twitterData')
//                ->add('gplusUid')
//                ->add('gplusName')
//                ->add('gplusData')
//                ->add('token')
//                ->add('twoStepVerificationCode')
//                ->add('id')
            ->end();
        if (!$this->getSubject()->hasRole('ROLE_SUPER_ADMIN'))
        {
            $formMapper
                ->with('Administración')
                    ->add('roles', 'sonata_security_roles', array(
                        'expanded' => true,
                        'multiple' => true,
                        'required' => false
                    ))
                    ->add('locked', null, array('required' => false))
                    ->add('expired', null, array('required' => false))
                    ->add('enabled', null, array('required' => false))
                    ->add('credentialsExpired', null, array('required' => false))
                ->end();
        }
    }

    /**
     * @param ShowMapper $showMapper
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->add('username')
//            ->add('usernameCanonical')
            ->add('email')
//            ->add('emailCanonical')
            ->add('enabled')
//            ->add('salt')
            ->add('password')
            ->add('lastLogin')
            ->add('locked')
//            ->add('expired')
//            ->add('expiresAt')
//            ->add('confirmationToken')
//            ->add('passwordRequestedAt')
            ->add('roles')
//            ->add('credentialsExpired')
//            ->add('credentialsExpireAt')
//            ->add('createdAt')
//            ->add('updatedAt')
//            ->add('dateOfBirth')
//            ->add('firstname')
//            ->add('lastname')
//            ->add('website')
//            ->add('biography')
//            ->add('gender')
//            ->add('locale')
//            ->add('timezone')
//            ->add('phone')
//            ->add('facebookUid')
//            ->add('facebookName')
//            ->add('facebookData')
//            ->add('twitterUid')
//            ->add('twitterName')
//            ->add('twitterData')
//            ->add('gplusUid')
//            ->add('gplusName')
//            ->add('gplusData')
//            ->add('token')
//            ->add('twoStepVerificationCode')
//            ->add('id')
        ;
    }
}
