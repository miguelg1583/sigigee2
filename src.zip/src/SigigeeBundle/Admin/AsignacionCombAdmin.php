<?php

namespace SigigeeBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;

class AsignacionCombAdmin extends AbstractAdmin
{
    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {

        $datagridMapper
//            ->add('id')
            ->add('provincia')
            ->add('entidad')
            ->add('gee')
            ->add('tipoDistribucion')
            ->add('combustible')
//            ->add('$fechaSolic')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
//            ->add('id')
            ->add('provincia')
            ->add('entidad')
            ->add('gee', null, array('label'=>'GEE'))
            ->add('tipoDistribucion', null, array('label'=>'Tipo Distribución'))
            ->add('combustible', null, array('label'=>'Combustible (lts)'))
            ->add('fechaSolic', 'date', array('format'=>'d/m/Y', 'label'=>'Fecha Solicitud'))
//            ->add('_action', null, array(
//                'actions' => array(
//                    'edit' => array(),
////                    'delete' => array(),
//                )
//            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {

//            private $id;
//            private $provincia;
//            private $entidad;
//            private $gee;
//            private $tipoDistribucion;
//            private $combustible;
//            private $fechaSolic;
        $formMapper
            ->with('Entidad', array('class'=>'col-md-6'))
                ->add('provincia', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\Provincia', 'required'=>true))
                ->add('entidad', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\Entidad', 'required'=>true))
                ->add('gee', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\ExistenciaGee', 'required'=>false))
                ->add('fechaSolic')
            ->end()
            ->with('Valores', array('class'=>'col-md-6'))
                ->add('combustible')
//                ->add('concepto', null, array('required'=>true))
                ->add('tipoDistribucion', null, array('required'=>true))
            ->end()
        ;
    }


}
