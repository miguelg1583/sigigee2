<?php

namespace SigigeeBundle\Admin;

//use Doctrine\ORM\QueryBuilder;
use SigigeeBundle\Entity\AsignacionComb;
use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Route\RouteCollection;
//use Sonata\AdminBundle\Show\ShowMapper;

class CertifOperacionAdmin extends AbstractAdmin
{
    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
//            ->add('id')
            ->add('gee')
            ->add('mes')
            ->add('anno')
            ->add('municipio')
            ->add('centro')
            ->add('marca')
            ->add('kvaVoltajeSalida')
//            ->add('deletedAt')
            ->add('operacSinCarga')
            ->add('operacConCarga')
            ->add('horasSinCarga')
            ->add('horasConCarga')
            ->add('energiaGenerada')
            ->add('combustSinCarga')
            ->add('combustConCarga')
            ->add('estadoCertificacion')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
//            ->add('id')
//            ->add('deletedAt')
            ->add('gee')
            ->add('mes')
            ->add('anno', null, array('label'=>'Año'))
            ->add('municipio')
            ->add('centro')
            ->add('marca')
            ->add('kvaVoltajeSalida')
            ->add('operacSinCarga')
            ->add('operacConCarga')
            ->add('horasSinCarga')
            ->add('horasConCarga')
            ->add('energiaGenerada')
            ->add('combustSinCarga')
            ->add('combustConCarga')
            ->add('estadoCertificacion', null, array('label'=>'Estado'))
            ->add('_action', null, array(
                'actions' => array(
//                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                    'validar' => array('template' => 'SigigeeBundle:CRUD:list__action_certificar.html.twig')
                ),
                'label'=>'Acciones'));
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
//            ->add('id')
//            ->add('deletedAt')
            ->with('GEE', array('class' => 'col-md-6'))
            ->add('gee', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\ExistenciaGee', 'required'=>true))
            ->add('mes')
            ->add('anno', null, array('label'=>'Año'))
            ->add('municipio', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\Municipio', 'required'=>true))
            ->add('centro', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\Entidad', 'required'=>true))
            ->add('marca', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\NomMarca', 'required'=>true))
            ->add('kvaVoltajeSalida', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\NomVoltaje', 'required'=>true))
            ->end()
            ->with('Operaciones', array('class' => 'col-md-3'))
            ->add('operacSinCarga', null, array('label'=>'Sin Carga'))
            ->add('operacConCarga', null, array('label'=>'Con Carga'))
            ->end()
            ->with('Horas Trabajadas', array('class' => 'col-md-3'))
            ->add('horasSinCarga', null, array('label'=>'Sin Carga'))
            ->add('horasConCarga', null, array('label'=>'Con Carga'))
            ->end()
            ->with('Energía Generada (Kw)', array('class' => 'col-md-3'))
            ->add('energiaGenerada')
            ->end()
            ->with('Combustible Consumido', array('class' => 'col-md-3'))
            ->add('combustSinCarga', null, array('label'=>'Sin Carga'))
            ->add('combustConCarga', null, array('label'=>'Con Carga'))
            ->end()
            ->with('Estado Certificacion', array('class' => 'col-md-3'))
            ->add('estadoCertificacion', null, array('label'=>'Estado'))
            ->end()
        ;
    }
    protected function configureRoutes(RouteCollection $collection)
    {
        $collection->add('certificar', $this->getRouterIdParameter().'/certificar');
    }

}
