<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 09/09/16
 * Time: 02:49 PM
 */

namespace SigigeeBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Form\FormMapper;

class EntidadAdmin extends AbstractAdmin
{

// Fields to be shown on create/edit forms
    protected function configureFormFields(FormMapper $formMapper)
    {
//        ->add('category', 'sonata_type_model', array(
//        'class' => 'AppBundle\Entity\Category',
//        'property' => 'name',
        $formMapper
            ->with('Datos', array('class' => 'col-md-6'))
            ->add('nombre')
            ->add('moneda', 'sonata_type_model', array('class'=>'SigigeeBundle\Entity\NomMoneda'))
            ->add('entidadSuperior', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\Entidad', 'property' => 'nombre', 'required' => false))
            ->add('ministerio', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\Ministerio', 'property' => 'siglas'))
            ->end()
            ->with('Ubicación', array('class' => 'col-md-6'))
            ->add('direccion')
            ->add('provincia', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\Provincia', 'property' => 'nombre'))
            ->add('municipio', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\Municipio', 'property' => 'nombre'))
            ->end()
        ;
    }

    // Fields to be shown on filter forms
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('nombre')
            ->add('entidadSuperior')
            ->add('ministerio')
            ->add('provincia')
            ->add('municipio')
        ;
    }

    // Fields to be shown on lists
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
//            ->addIdentifier('id')
            ->add('nombre')
            ->add('moneda')
            ->add('entidadSuperior')
            ->add('ministerio')
            ->add('direccion',null,array('label'=>'Dirección'))
            ->add('provincia')
            ->add('municipio')
            ->add('_action', 'Acciones', array(
                'actions' => array(
                    'edit' => array(),
                    'delete' => array()
                ),
                'label'=>'Acciones'));
    }
}