<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 11/09/16
 * Time: 06:01 PM
 */
namespace SigigeeBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\CoreBundle\Validator\ErrorElement;
//use Symfony\Component\Validator\Constraints\DateTime;

//use Sonata\CoreBundle\Validator\ErrorElement;
//use Symfony\Component\Validator\Constraints\Length;
//use Symfony\Component\Validator\Constraints\NotBlank;


class ExistenciaGeeAdmin extends AbstractAdmin
{
//    protected $formOptions = array('validation_groups'=>array('invUnico', 'invCantCaract', 'invPatron'));
//    protected $formOptions = array();

// $errorElement
// ->with(’settings.url’)
// ->assertNotNull(array())
// ->assertNotBlank()
// ->end()
// ->with(’settings.title’)
// ->assertNotNull(array())
// ->assertNotBlank()
// ->assertMinLength(array(’limit’ => 50))
// ->addViolation(’ho yeah!’)
// ->end();
// Fields to be shown on create/edit forms

    protected function myanno()
    {
        $time= new \DateTime('now');
        return $time->modify('-3 year')->format('Y-m-d');
    }
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('Datos', array('class' => 'col-md-4'))
//            ->add('noInventario', null, array('help'=>'El No de Inventario ha de ser único'))
            ->add('noInventario', null, array('required'=>true))
            ->add('fechaEntrada', 'sonata_type_date_picker', array('dp_use_current'=>true, 'dp_min_date' => $this->myanno(), 'dp_max_date' => getdate()))
            ->add('tipoGee', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\NomGee', 'label'=>'Tipo de GEE', 'required'=>true))
//            ->add('estado', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\EstadoGee', 'required'=>true))
            ->add('instrumentos', null, array('label'=>'Instrumentos en correcto estado', 'required'=>true))
            ->end()
            ->with('Valores', array('class' => 'col-md-4'))
            ->add('indiceCarga', null, array('required'=>true, 'label'=>'Índice de Consumo con Carga'))
            ->add('indiceSinCarga', null, array('required'=>true, 'label'=>'Índice de Consumo Sin Carga'))
            ->add('tanquePropio', null, array('required'=>true,'label'=>'Capacidad de combustible en el Tanque Propio (L)'))
            ->add('tanqueAux', null, array('required'=>true,'label'=>'Capacidad de combustible en el Tanque Auxiliar (L)'))
//            ->add('cantComb', null, array('label'=>'Cantidad de Combustible (L) en existencia'))
//            ->add('coberturaHoras')
            ->end()
            ->with('Ubicación', array('class' => 'col-md-4'))
            ->add('entidad', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\Entidad', 'property' => 'nombre', 'required'=>true))
            ->add('distribucion', null, array('required'=>true, 'label'=>'Forma de Distribución del Combustible'))
            ->end()
        ;
//        $valor=$this->getForm()->getData('noInventario');
    }

    // Fields to be shown on filter forms
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('noInventario')
            ->add('fechaEntrada', 'doctrine_orm_date_range', array('field_type'=>'sonata_type_date_range_picker'))
            ->add('tipoGee')
            ->add('entidad')
            ->add('distribucion')
            ->add('estado')
            ->add('instrumentos')
            ->add('indiceCarga')
            ->add('indiceSinCarga')
            ->add('tanquePropio')
            ->add('tanqueAux')
            ->add('cantComb')
            ->add('coberturaHoras')
        ;
    }

    // Fields to be shown on lists
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
//            ->addIdentifier('id')
            ->add('noInventario')
            ->add('fechaEntrada', 'date', array('format'=>'d/m/Y'))
            ->add('tipoGee')
            ->add('entidad')
            ->add('distribucion', null, array('label'=>'Distribución', 'associated_property'=>'getSigla'))
            ->add('estado')
            ->add('instrumentos', 'boolean', array('editable'=>true, 'required'=>true, 'label'=>'Instrumentos Correctos'))
            ->add('indiceCarga', null, array('label'=>'Índice Con Carga (L/h)'))
            ->add('indiceSinCarga', null, array('label'=>'Índice Sin Carga (L/h)'))
            ->add('tanquePropio', null, array('label'=>'Tanque Propio (L)'))
            ->add('tanqueAux', null, array('label'=>'Tanque Auxiliar (L)'))
            ->add('cantComb', null, array('label'=>'Cantidad Combustible (L)'))
            ->add('coberturaHoras', null, array('label'=>'Cobertura en Horas'))
            ->add('_action', 'actions', array(
                'actions' => array(
                    'edit' => array(),
                    'delete' => array()
                ),
                'label'=>'Acciones'));
    }

    public function prePersist($object)
    {
        $object->setCoberturaHoras(round(($object->getCantComb()/$object->getIndiceCarga()),2)?:0);
    }

    public function preUpdate($object)
    {
        $object->setCoberturaHoras(round(($object->getCantComb()/$object->getIndiceCarga()),2)?:0);
    }

    public function validate(ErrorElement $errorElement, $object)
    {
        //=======> esto no metrabaja porque uso assert para no Invet    YA TRABAJA

        //$object ES LA ENTIDAD A AGREGAR Y O MODIFICAR
//   ///////////////////////////////////////////////////
//ESTE ES EL TIPO     $em=$this->getConfigurationPool()->getContainer()->get('Doctrine')->getRepository('SigigeeBundle:ExistenciaGee')->
//        throw new \Exception(strlen($object->getNoInventario()));
        if(strlen($object->getNoInventario())!=6)
        {
            $errorElement
                ->with('noInventario')->addViolation('El No Inventario tiene que ser de 6 caracteres')
                ->end();
        }

        if(!preg_match('/CH\d\d\d\d/', $object->getNoInventario()))
        {
            $errorElement
                ->with('noInventario')->addViolation('El Formato del No Inventario tiene que ser CH####')
                ->end();
        }

        if($this->isCurrentRoute('create')){
        $existenciaGEE=$this->getConfigurationPool()->getContainer()->get('doctrine')->getRepository('SigigeeBundle:ExistenciaGee')->findOneBy(array('noInventario'=>$object->getNoInventario()));
        if($existenciaGEE)
        {
            $errorElement
                ->with('noInventario')->addViolation('El No de Inventario especificado existe y tiene que ser único')
                ->end();
        }}
//ESTO NO ES NECESARIO PORQUE SONATA LO HACE SOLO
//        if(!is_float($object->getIndiceCarga())){$errorElement->with('indiceCarga')->addViolation('El valor entrado no es un número decimal')->end();}
//        if(!is_float($object->getIndiceSinCarga())){$errorElement->with('indiceSinCarga')->addViolation('El valor entrado no es un número decimal')->end();}
//        if(!is_float($object->getTanquePropio())){$errorElement->with('tanquePropio')->addViolation('El valor entrado no es un número decimal')->end();}
//        if(!is_float($object->getTanqueAux())){$errorElement->with('tanqueAux')->addViolation('El valor entrado no es un número decimal')->end();}
    }


}