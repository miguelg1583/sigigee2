<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 11/09/16
 * Time: 02:43 PM
 */
namespace SigigeeBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Form\FormMapper;

//use SigigeeBundle\Entity\NomGee;

class NomGeeAdmin extends AbstractAdmin
{
//    public function createQuery($context = 'list')
//    {
//        $query = parent::createQuery($context);
//        $query->->andWhere(
//            $query->expr()->eq($query->getRootAliases()[0] . '.my_field', ':my_param')
//        );
//        $query->setParameter('my_param', 'my_value');
//        return $query;
//    }

// Fields to be shown on create/edit forms
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
//->with('Modelo')
            ->add('modelo')
            ->end()
            ->with('Potencia', array('class' => 'col-md-6'))
                ->add('potenciaSalida', null, array('label'=>'Potencia'))
                ->add('potenciaSalidaUM', null, array('label'=>'UM'))
            ->end()
            ->with('Corriente', array('class' => 'col-md-6'))
            ->add('corrienteSalida')
            ->add('corrienteSalidaUM')
            ->end()
//            ->with('Longitudes')
            ->with('Largo', array('class' => 'col-md-3'))
            ->add('largo')
            ->add('largoUM')
            ->end()
            ->with('Ancho', array('class' => 'col-md-3'))
            ->add('ancho')
            ->add('anchoUM')
            ->end()
            ->with('Alto', array('class' => 'col-md-3'))
            ->add('alto')
            ->add('altoUM')
            ->end()
            ->with('Peso', array('class' => 'col-md-3'))
            ->add('peso')
            ->add('pesoUM')
            ->end()
            ->with('Componentes', array('class' => 'col-md-6'))
            ->add('marca')
            ->add('motor')
            ->add('generador')
            ->end()
            ->with('Voltaje', array('class' => 'col-md-6'))
            ->add('voltajeSalida')
            ->end()
        ;
    }

    // Fields to be shown on filter forms
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('modelo')
            ->add('corrienteSalida')
            ->add('corrienteSalidaUM')
            ->add('potenciaSalida')
            ->add('potenciaSalidaUM')
            ->add('largo')
            ->add('largoUM')
            ->add('ancho')
            ->add('anchoUM')
            ->add('alto')
            ->add('altoUM')
            ->add('peso')
            ->add('pesoUM')
            ->add('marca')
            ->add('motor')
            ->add('generador')
            ->add('voltajeSalida')
        ;
    }

    // Fields to be shown on lists
    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
//            ->addIdentifier('id')
            ->add('modelo')
//            ->add('corrienteSalida'." ".'corrienteSalidaUM', null, array('label' => 'Corriente'))
//            ->add('corrienteSalida', null, array('associated_tostring' => 'getCorriente_con_UM'))
//            ->add('NomGee.getCorriente_con_UM')
//            ->add('corrienteSalida')
//            ->add('corrienteSalidaUM')
//            ->with('Corriente Salida')
                ->add('corrienteSalida', null, array('label'=>'Corriente', 'code' => 'getCorrienteConUM'))
//                ->add('corrienteSalidaUM', null, array('label'=>'UM'))
//            ->end()
            ->add('potenciaSalida', null, array('label'=>'Potencia', 'code' => 'getPotenciaConUm'))
//            ->add('potenciaSalidaUM', null, array('label'=>'UM'))
            ->add('largo', null, array('code' => 'getLargoConUm'))
//            ->add('largoUM', null, array('label'=>'UM'))
            ->add('ancho', null, array('code' => 'getAnchoConUm'))
//            ->add('anchoUM', null, array('label'=>'UM'))
            ->add('alto', null, array('code' => 'getAltoConUm'))
//            ->add('altoUM', null, array('label'=>'UM'))
            ->add('peso', null, array('code' => 'getPesoConUm'))
//            ->add('pesoUM', null, array('label'=>'UM'))
            ->add('marca')
            ->add('motor')
            ->add('generador')
            ->add('voltajeSalida')
            ->add('_action', 'actions', array(
                'actions' => array(
                    'edit' => array(),
                    'delete' => array()
                ),
                'label'=>'Acciones'));
    }
}