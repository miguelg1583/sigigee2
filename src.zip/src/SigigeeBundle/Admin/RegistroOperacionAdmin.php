<?php

namespace SigigeeBundle\Admin;

use SigigeeBundle\Entity\RegistroOperacion;
use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Route\RouteCollection;
use Sonata\CoreBundle\Validator\ErrorElement;

//use Sonata\AdminBundle\Show\ShowMapper;

class RegistroOperacionAdmin extends AbstractAdmin
{
    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper

            ->add('id')
//            ->add('deletedAt')
            ->add('dia')
            ->add('gee')
            ->add('tipo')
            ->add('horaInicial')
            ->add('horaFinal')
            ->add('horametroInicial')
            ->add('horametroFinal')
            ->add('tiempoTrabajado')
            ->add('demandaLiberada')
            ->add('energiaGenerada')
            ->add('combustibleConsumido')
            ->add('combustibleExistencia')
            ->add('observaciones')
            ->add('quienReporta')
            ->add('estadoOperacion')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->add('id')
//            ->add('deletedAt')
            ->add('dia', null, array('label'=>'Día'))
            ->add('gee')
            ->add('tipo')
            ->add('horaInicial')
            ->add('horaFinal')
            ->add('horametroInicial', null, array('label'=>'Horámetro Inicial'))
            ->add('horametroFinal', null, array('label'=>'Horámetro Final'))
//            ->add('tiempoTrabajado')
//            ->add('demandaLiberada')
            ->add('energiaGenerada', null, array('label'=>'Energía Generada'))
            ->add('combustibleConsumido')
            ->add('combustibleExistencia')
            ->add('observaciones')
            ->add('quienReporta')
//            ->add('estadoOperacion')
            ->add('_action', null, array(
                'actions' => array(
//                    'show' => array(),
                    'edit' => array(),
                    'delete' => array(),
                    'validar' => array('template' => 'SigigeeBundle:CRUD:list__action_validar.html.twig')
                ),
                'label'=>'Acciones'));

    }
    protected function unDiaMenos()
    {
        $time= new \DateTime('now');
        return $time->modify('-1 day')->format('Y-m-d');
    }
    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
//            ->add('id')
//            ->add('deletedAt')
            ->with('Datos', array('class' => 'col-md-3'))
            ->add('dia', 'sonata_type_date_picker', array('dp_use_current'=>true, 'dp_min_date' => $this->unDiaMenos(), 'dp_max_date' => getdate(), 'label'=>'Día'))
            ->add('gee', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\ExistenciaGee', 'required'=>true))
            ->add('tipo', 'sonata_type_model', array('class' => 'SigigeeBundle\Entity\TipoOperacion', 'required'=>true))
//            ->add('estadoOperacion', null, array('required'=>true))
            ->end()
            ->with('Horas', array('class' => 'col-md-3'))
            ->add('horaInicial')
            ->add('horaFinal')
            ->add('horametroInicial', null, array('label'=>'Horámetro Inicial'))
            ->add('horametroFinal', null, array('label'=>'Horámetro Final'))
//            ->add('tiempoTrabajado')
            ->end()
            ->with('Energía y Combustible', array('class' => 'col-md-3'))
//            ->add('demandaLiberada')
            ->add('energiaGenerada', null, array('label'=>'Energía Generada'))
            ->add('combustibleConsumido')
            ->add('combustibleExistencia')
            ->end()
            ->with('Personal que reporta', array('class' => 'col-md-3'))
            ->add('observaciones')
            ->add('quienReporta')
            ->end()
        ;
    }

    protected function configureRoutes(RouteCollection $collection)
    {
        $collection->add('validar', $this->getRouterIdParameter().'/validar');
    }

    public function prePersist($object)
    {
//        $object->setTiempoTrabajado(round(($object->getHorametroFinal()-$object->getHorametroInicial()),2)?:0);
        $object->setEstadoOperacion($this->getConfigurationPool()->getContainer()->get('doctrine')->getRepository('SigigeeBundle:EstadoOperacion')->findOneBy(array("nombre"=>"Sin Validar")));
    }

    public function preUpdate($object)
    {
//        $object->setTiempoTrabajado(round(($object->getHorametroFinal()-$object->getHorametroInicial()),2)?:0);
    }

    public function validate(ErrorElement $errorElement, $object)
    {
        if($object->getDia()<$this->getConfigurationPool()->getContainer()->get('doctrine')->getRepository('SigigeeBundle:ExistenciaGee')->find($object->getGee()->getId())->getFechaEntrada())
        {
            $errorElement
                ->with('dia')->addViolation('La fecha de la operación tiene que ser posterior a la fecha de entrada existencia del GEE')
                ->end();
        }

        if($object->getHorametroFinal()<$object->getHorametroInicial())
        {
            $errorElement
                ->with('horametroFinal')->addViolation('El valor del horámetro final tiene que ser mayor que el del horámetro inicial')
                ->end();
        }

        if($object->getHoraFinal()<$object->getHoraInicial())
        {
            $errorElement
                ->with('horaFinal')->addViolation('El valor de la hora final tiene que ser mayor que el de la hora inicial')
                ->end();
        }

        $doct=$this->getConfigurationPool()->getContainer()->get('doctrine');
        $operacionAnterior=$doct->getRepository('SigigeeBundle:RegistroOperacion')->findOperacionAnterior($object->getGee(), $object->getId());
        if($object->getHorametroInicial()<>$operacionAnterior->getHorametroFinal())
        {
            $errorElement
                ->with('horametroInicial')->addViolation('El valor del horámetro inicial tiene que ser el valor del horámetro final de la operación anterior del gee ('.$operacionAnterior->getHorametroFinal().').')
                ->end();
        }
//        parent::validate($errorElement, $object); // TODO: Change the autogenerated stub
        //$object ES LA ENTIDAD A AGREGAR Y O MODIFICAR
//   ///////////////////////////////////////////////////
//ESTE ES EL TIPO     $em=$this->getConfigurationPool()->getContainer()->get('Doctrine')->getRepository('SigigeeBundle:ExistenciaGee')->
    }

    public function configureBatchActions($actions)
    {
        $actions['validar'] = array('label' => 'Validar', 'ask_confirmation' => true);
        return $actions;
//        return parent::configureBatchActions($actions); // TODO: Change the autogenerated stub
    }

//    public function getBatchActions()
//    {// retrieve the default batch actions (currently only delete)
//        $actions = parent::getBatchActions();
//
//        $actions['validar'] = array('label' => 'Validar', 'ask_confirmation' => true);
//        return $actions;
//    }


}
