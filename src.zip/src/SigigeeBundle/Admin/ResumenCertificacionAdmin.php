<?php

namespace SigigeeBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;

class ResumenCertificacionAdmin extends AbstractAdmin
{
    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
//            ->add('id')
            ->add('mes')
            ->add('anno')
            ->add('operacSinCarga')
            ->add('operacCarga')
            ->add('horasSinCarga')
            ->add('horasCarga')
            ->add('energiaGenerada')
            ->add('combustSinCarga')
            ->add('combustCarga')
            ->add('combustTotal')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
//            ->add('id')
            ->add('gee')
            ->add('mes')
            ->add('anno')
            ->add('municipio')
            ->add('centro')
            ->add('marca')
            ->add('operacSinCarga')
            ->add('operacCarga')
            ->add('horasSinCarga')
            ->add('horasCarga')
            ->add('energiaGenerada')
            ->add('combustSinCarga')
            ->add('combustCarga')
            ->add('combustTotal')
            ->add('_action', null, array(
                'actions' => array(
//                    'show' => array(),
                    'edit' => array(),
                    'delete' => array()
                ),
                'label'=>'Acciones'));
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {

//        private $gee;
//        private $municipio;
//        private $centro;
//        private $marca;
        $formMapper
//            ->add('id')
            ->add('gee')
            ->add('mes')
            ->add('anno')
//            ->add('municipio')
//            ->add('centro')
//            ->add('marca')
            ->add('operacSinCarga')
            ->add('operacCarga')
            ->add('horasSinCarga')
            ->add('horasCarga')
            ->add('energiaGenerada')
            ->add('combustSinCarga')
            ->add('combustCarga')
//            ->add('combustTotal')     hacerlo yo
        ;
    }

    public function prePersist($object)
    {
        $object->setCentro($object->getGee()->getEntidad());
        $object->setMunicipio($object->getGee()->getEntidad()->getMunicipio());
        $object->setCentro($object->getGee()->getMarca());
    }

    public function preUpdate($object)
    {
        $object->setCentro($object->getGee()->getEntidad());
        $object->setMunicipio($object->getGee()->getEntidad()->getMunicipio());
        $object->setCentro($object->getGee()->getMarca());
    }


}
