<?php

namespace SigigeeBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\CoreBundle\Validator\ErrorElement;

//use Sonata\AdminBundle\Show\ShowMapper;
//use Sonata\CoreBundle\Validator\ErrorElement;

class SolicCombLlenadoInicialAdmin extends AbstractAdmin
{
    /**
     * @param DatagridMapper $datagridMapper
     */
    protected $datagridValues=array('_sort_order'=>'DESC', '_sort_by'=>'fechaSolicitud', '_per_page'=>16);

    public function createQuery($context = 'list')
    {
        $aprobadoPendiente=$this->getModelManager()->findOneBy('SigigeeBundle:EstadoAprobacion', array('nombre'=>'Pendiente'));

        $query = parent::createQuery($context);
        $query->andWhere(
            $query->expr()->eq($query->getRootAlias() . '.aprobado', ':aprobPendiente')
                );
        $query->setParameter('aprobPendiente',  $aprobadoPendiente);
        return $query;
    }


    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('id')
            ->add('fechaSolicitud')
            ->add('fechaAprobacion')
            ->add('descripcion')
            ->add('noCartaAprobacion')
            ->add('aprobado')
            ->add('cantidad')
            ->add('observaciones')
            ->add('noOrdenDistribucion')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->addIdentifier('id')
            ->add('fechaSolicitud', 'date', array('format'=>'d/m/Y'))
//            ->add('fechaAprobacion', 'date', array('format'=>'d/m/Y', 'label'=>'Fecha Aprobación'))
            ->add('descripcion', null, array('label'=>'Descripción'))
//            ->add('noCartaAprobacion', null, array('label'=>'AC'))
//            ->add('aprobado')
            ->add('cantidad', null, array('label'=>'Cantidad (ton)'))
            ->add('distribucion', null, array('label'=>'Distribución', 'associated_property'=>'getSigla'))
            ->add('destinoFinal', null, array('label'=>'Destino'))
            ->add('gee')
//            ->add('observaciones')
//            ->add('noOrdenDistribucion', null, array('label'=>'OD'))
            ->add('_action', null, array(
                'actions' => array(
                    'edit' => array(),
                    'delete' => array()
                ),
                'label'=>'Acciones'));
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {

        $formMapper
//            ->add('id')
//            ->end()
            ->with('Solicitud', array('class'=>'col-md-6'))
            ->add('fechaSolicitud', 'sonata_type_date_picker', array('required'=>true, 'dp_max_date' => getdate(), 'label'=>'Fecha'))
//            ->add('fechaAprobacion', null, array('label'=>'Fecha Aprobación'))
//            ->add('gee', 'sonata_type_model', array('class'=>'SigigeeBundle\Entity\ExistenciaGee', 'label'=>'Gee', 'required' => true, 'help'=>'Si el GEE ya tiene registro dará error'))
            ->add('gee', 'sonata_type_model', array('class'=>'SigigeeBundle\Entity\ExistenciaGee', 'label'=>'Gee', 'required' => true))
            ->add('descripcion', 'textarea', array('label'=>'Descripción de la Entidad', 'required'=>false))
            ->end()
            ->with('Monto', array('class'=>'col-md-6'))
//            ->add('aprobado', null, array('required'=>true))
            ->add('cantidad', null, array('label'=>'Cantidad (ton)'))
            ->end()
//            ->with('Gee', array('class'=>'col-md-6'))

//            ->add('distribucion', null, array('required'=>true))
//            ->add('noCartaAprobacion',null, array('help'=>'# de la carta emitida por la DGE'))
//            ->add('destinoFinal', 'sonata_type_model', array('class'=>'SigigeeBundle\Entity\Entidad', 'label'=>'Destino Final', 'property' => 'nombre', 'required' => true, 'help'=>'Si la entidad ya tiene registro dará error'))
            //, null, array('help'=>'El No de Inventario ha de ser único'))
//            ->end()
//            ->with('Datos Extras', array('class'=>'col-md-6'))
//            ->add('observaciones')
//            ->add('noOrdenDistribucion', null, array('label'=>'# de Orden', 'help'=>'# de Orden de Distribucion de la DGE hacia CUPET Nacional'))
//            ->end()
        ;
    }

    public function prePersist($object)
    {
        $object->setDestinoFinal($object->getGee()->getEntidad());
        $object->setDistribucion($object->getGee()->getDistribucion());

        $doct=$this->getConfigurationPool()->getContainer()->get('doctrine');
        $aprobacionPendiente=$doct->getRepository('SigigeeBundle:EstadoAprobacion')->findOneBy(array('nombre'=>'pendiente'));
        $object->setAprobado($aprobacionPendiente);

    }

    public function preUpdate($object)
    {
        $object->setDestinoFinal($object->getGee()->getEntidad());
        $object->setDistribucion($object->getGee()->getDistribucion());
    }

    public function validate(ErrorElement $errorElement, $object)
    {
        $doct=$this->getConfigurationPool()->getContainer()->get('doctrine');

        if($object->getFechaSolicitud()<$object->getGee()->getFechaEntrada())
        {
            $errorElement
                ->with('fechaSolicitud')->addViolation('La fecha de solicitud de llenado incial tiene que ser igual o posterior a la fecha de entrada del GEE')
                ->end();
        }

        $td=$doct->getRepository('SigigeeBundle:TipoDistribucion')->findOneBy(array('sigla'=>'TD'));

        if($object->getGee()->getDistribucion()==$td && $object->getCantidad()*1188.78
            >$object->getGee()->getTanquePropio()+$object->getGee()->getTanqueAux())
        {
            $cantLitros=$object->getGee()->getTanquePropio()+$object->getGee()->getTanqueAux();
            $cantTon=$object->getGee()->getTanquePropio()+$object->getGee()->getTanqueAux()/1188.78;
            $errorElement
                ->with('cantidad')->addViolation('Imposible serviciar por TD una cantidad mayor que la capacidad del GEE ('.$cantLitros.' L -> '.$cantTon.' ton)')
                ->end();
        }

        if($object->getCantidad()*1188.78/$object->getGee()->getIndiceCarga()<66)
        {
            $cantNecesitada=$object->getGee()->getIndiceCarga()*66/1188.78;
            $errorElement
                ->with('cantidad')->addViolation('Se ha de asegurar al menos 66 horas de autonomía, para ello se necesita al menos: '.round($cantNecesitada, 2).' ton')
                ->end();
        }

        $solicExistente=$doct->getRepository('SigigeeBundle:SolicCombLlenadoInicial')->findOneBy(array('gee'=>$object->getGee()));
        if($solicExistente)
        {
            $errorElement
                ->with('gee')->addViolation('Al GEE seleccionado ya se le solicitó combustible para llenado inicial, el cual es sólo por una vez')
                ->end();
        }
    }


}
