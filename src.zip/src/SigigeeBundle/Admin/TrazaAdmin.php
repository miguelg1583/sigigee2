<?php

namespace SigigeeBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Show\ShowMapper;

class TrazaAdmin extends AbstractAdmin
{
    protected $datagridValues=array('_sort_order'=>'DESC', '_sort_by'=>'fecha', '_per_page'=>16);
    /**
     * @param DatagridMapper $datagridMapper
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('id')
            ->add('usuario')
            ->add('tabla')
            ->add('registro')
            ->add('ip')
            ->add('fecha')
            ->add('hora')
            ->add('accion')
        ;
    }

    /**
     * @param ListMapper $listMapper
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
//            ->add('id')
            ->add('usuario')
            ->add('tabla')
            ->add('registro')
            ->add('ip')
            ->add('fecha', 'date', array('format'=>'d/m/Y'))
            ->add('hora', 'time')
            ->add('accion')
//            ->add('_action', null, array(
//                'actions' => array(
//                    'show' => array(),
//                    'edit' => array(),
//                    'delete' => array(),
//                )
//            ))
        ;
    }

    /**
     * @param FormMapper $formMapper
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
//            ->add('id')
            ->add('usuario')
            ->add('tabla')
            ->add('registro')
            ->add('ip')
            ->add('fecha', 'date', array('format'=>'d/m/Y'))
            ->add('hora')
            ->add('accion')
        ;
    }

//    /**
//     * @param ShowMapper $showMapper
//     */
//    protected function configureShowFields(ShowMapper $showMapper)
//    {
//        $showMapper
//            ->add('id')
//            ->add('usuario')
//            ->add('tabla')
//            ->add('registro')
//            ->add('ip')
//            ->add('fecha')
//            ->add('hora')
//            ->add('accion')
//        ;
//    }
}
