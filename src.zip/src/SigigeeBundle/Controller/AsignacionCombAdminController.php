<?php

namespace SigigeeBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController;

class AsignacionCombAdminController extends CRUDController
{


}
