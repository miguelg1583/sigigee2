<?php

namespace SigigeeBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController;
use Symfony\Component\HttpFoundation\RedirectResponse;

class CertifOperacionAdminController extends CRUDController
{
    public function certificarAction()
    {
        $id = $this->get('request')->get($this->admin->getIdParameter());
        $operacion = $this->admin->getObject($id); //CertifOperacion
        if (!$operacion) {
//            throw new NotFoundHttpException(sprintf('Imposible encontrar operación con id : %s', $id));
            $this->addFlash('sonata_flash_error', sprintf('Imposible encontrar certificación con id : %s', $id));
            return new RedirectResponse($this->admin->generateUrl('list'));
        }

        $em = $this->getDoctrine()->getManager();
        $estadoOpCert=$em->getRepository('SigigeeBundle:EstadoCertificacion')->findOneBy(array('nombre'=>'Certificado'));
        if($operacion->getEstadoCertificacion()==$estadoOpCert)
        {
            $this->addFlash('sonata_flash_info', 'Ya se certificó este combustible');
            return new RedirectResponse($this->admin->generateUrl('list'));
        }
        $operacion->setEstadoCertificacion($estadoOpCert);
        $this->admin->update($operacion);

//        //paso a resumen
//        $resumen=$em->getRepository()
//
//            $operacCertif=$em->getRepository('SigigeeBundle:CertifOperacion')->findOneBy(array('gee'=>$operacion->getGee(), 'mes'=>$mes, 'anno'=>$anno));
//            if(is_null($operacCertif)) //no hay registro de certif (1ra operacion)
//            {

        $this->addFlash('sonata_flash_success', 'Combustible certificado Satisfactoriamente');
        return new RedirectResponse($this->admin->generateUrl('list'));
    }

}
