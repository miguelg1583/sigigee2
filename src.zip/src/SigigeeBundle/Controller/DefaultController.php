<?php

namespace SigigeeBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
//        return $this->render('SigigeeBundle:Default:index.html.twig');

        return $this->redirectToRoute('sonata_admin_dashboard');


    }
}
