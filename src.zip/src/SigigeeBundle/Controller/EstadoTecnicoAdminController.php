<?php

namespace SigigeeBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController;

class EstadoTecnicoAdminController extends CRUDController
{

}
