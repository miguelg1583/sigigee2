<?php

namespace SigigeeBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController;

class NomMonedaAdminController extends CRUDController
{

}
