<?php

namespace SigigeeBundle\Controller;

use SigigeeBundle\Entity\CertifOperacion;
use Sonata\AdminBundle\Controller\CRUDController;
use Sonata\AdminBundle\Datagrid\ProxyQueryInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class RegistroOperacionAdminController extends CRUDController
{
    public function validarAction()
    {
        $id = $this->get('request')->get($this->admin->getIdParameter());
        $operacion = $this->admin->getObject($id);
        if (!$operacion) {//obtengo operacion sino exception
//            throw new NotFoundHttpException(sprintf('Imposible encontrar operación con id : %s', $id));
            $this->addFlash('sonata_flash_error', sprintf('Imposible encontrar operación con id : %s', $id));
            return new RedirectResponse($this->admin->generateUrl('list'));
        }
        $em = $this->getDoctrine()->getManager();


        $estadoOpValid=$em->getRepository('SigigeeBundle:EstadoOperacion')->findOneBy(array('nombre'=>'Validada'));
        $gee=$em->getRepository("SigigeeBundle:ExistenciaGee")->find($operacion->getGee()->getId());
        if($operacion->getEstadoOperacion()==$estadoOpValid) //ya esta validada
        {
            $this->addFlash('sonata_flash_info', 'Ya se validó esta operación');
            return new RedirectResponse($this->admin->generateUrl('list'));
        }
        else
        {

            $mes=getdate(date_timestamp_get($operacion->getDia()))['mon'];
            $anno=getdate(date_timestamp_get($operacion->getDia()))['year'];
            $operacCertif=$em->getRepository('SigigeeBundle:CertifOperacion')->findOneBy(array('gee'=>$operacion->getGee(), 'mes'=>$mes, 'anno'=>$anno));
            if(is_null($operacCertif)) //no hay registro de certif (1ra operacion)
            {
                $ps=$em->getRepository('SigigeeBundle:TipoOperacion')->findOneBy(array('sigla'=>'PS'));
                $iu=$em->getRepository('SigigeeBundle:TipoOperacion')->findOneBy(array('sigla'=>'IU'));
                $ls=$em->getRepository('SigigeeBundle:TipoOperacion')->findOneBy(array('sigla'=>'LS'));
                if($operacion->getTipo()==$ps or $operacion->getTipo()==$iu or $operacion->getTipo()==$ls) //operaciones sin carga
                {
                    $operacion->setCombustibleConsumido(round($gee->getIndiceSinCarga()*$operacion->getTiempoTrabajado(),2));
                    $operacion->setCombustibleExistencia($gee->getCantComb()-$operacion->getCombustibleConsumido());
                    $operacion->setEstadoOperacion($estadoOpValid);
                    $gee->setCantComb($operacion->getCombustibleExistencia());

                    $em->flush();

                    $this->admin->update($operacion);

                    $certf=new CertifOperacion();
                    $certf
                        ->setOperacSinCarga(1)
                        ->setOperacConCarga(0)
                        ->setHorasSinCarga($operacion->getTiempoTrabajado())
                        ->setHorasConCarga(0)
                        ->setEnergiaGenerada($operacion->getEnergiaGenerada())
                        ->setCombustSinCarga($operacion->getCombustibleConsumido())
                        ->setCombustConCarga(0)
                        ->setGee($operacion->getGee())
                        ->setMunicipio($operacion->getGee()->getEntidad()->getMunicipio())
                        ->setCentro($operacion->getGee()->getEntidad())
                        ->setMarca($operacion->getGee()->getTipoGee()->getMarca())
                        ->setKvaVoltajeSalida($operacion->getGee()->getTipoGee()->getVoltajeSalida())
                        ->setMes($mes)
                        ->setAnno($anno)
                    ;
                    $em->persist($certf);
                    $em->flush();
                }
                else
                {                   //operaciones con carga
                    $operacion->setCombustibleConsumido(round($gee->getIndiceCarga()*$operacion->getTiempoTrabajado(),2));
                    $operacion->setCombustibleExistencia($gee->getCantComb()-$operacion->getCombustibleConsumido());
                    $operacion->setEstadoOperacion($estadoOpValid);
                    $gee->setCantComb($operacion->getCombustibleExistencia());

                    $em->flush();

                    $this->admin->update($operacion);

                    //operaciones con carga
                    $certf=new CertifOperacion();
                    $certf
//                ->setOperacSinCarga(1)
                        ->setOperacConCarga(1)
//                ->setHorasSinCarga($operacion->getTiempoTrabajado())
                        ->setHorasConCarga($operacion->getTiempoTrabajado())
                        ->setEnergiaGenerada($operacion->getEnergiaGenerada())
//                ->setCombustSinCarga($operacion->getCombustibleConsumido())
                        ->setCombustConCarga($operacion->getCombustibleConsumido())
                        ->setGee($operacion->getGee())
                        ->setMunicipio($operacion->getGee()->getEntidad()->getMunicipio())
                        ->setCentro($operacion->getGee()->getEntidad())
                        ->setMarca($operacion->getGee()->getTipoGee()->getMarca())
                        ->setKvaVoltajeSalida($operacion->getGee()->getTipoGee()->getVoltajeSalida())
                        ->setMes($mes)
                        ->setAnno($anno)
                    ;
                    $em->persist($certf);
                    $em->flush();
                }

            }
            else    //hay registros de certificacion
            {
                $ps=$em->getRepository('SigigeeBundle:TipoOperacion')->findOneBy(array('sigla'=>'PS'));
                $iu=$em->getRepository('SigigeeBundle:TipoOperacion')->findOneBy(array('sigla'=>'IU'));
                $ls=$em->getRepository('SigigeeBundle:TipoOperacion')->findOneBy(array('sigla'=>'LS'));
                if($operacion->getTipo()==$ps or $operacion->getTipo()==$iu or $operacion->getTipo()==$ls) //operaciones sin carga
                {
                    $operacion->setCombustibleConsumido(round($gee->getIndiceSinCarga()*$operacion->getTiempoTrabajado(),2));
                    $operacion->setCombustibleExistencia($gee->getCantComb()-$operacion->getCombustibleConsumido());
                    $operacion->setEstadoOperacion($estadoOpValid);
                    $gee->setCantComb($operacion->getCombustibleExistencia());

                    $em->flush();

                    $this->admin->update($operacion);

                    $operacCertif
                        ->setOperacSinCarga($operacCertif->getOperacSinCarga()+1)
//                    ->setOperacConCarga()
                        ->setHorasSinCarga($operacCertif->getHorasSinCarga()+$operacion->getTiempoTrabajado())
//                    ->setHorasConCarga()
                        ->setEnergiaGenerada($operacCertif->getEnergiaGenerada()+$operacion->getEnergiaGenerada())
                        ->setCombustSinCarga($operacCertif->getCombustSinCarga()+$operacion->getCombustibleConsumido())
//                    ->setCombustConCarga()
                    ;
//            $em->persist($operacCertif);
                    $em->flush();
                }
                else
                {//operaciones con carga
                    $operacion->setCombustibleConsumido(round($gee->getIndiceCarga()*$operacion->getTiempoTrabajado(),2));
                    $operacion->setCombustibleExistencia($gee->getCantComb()-$operacion->getCombustibleConsumido());
                    $operacion->setEstadoOperacion($estadoOpValid);
                    $gee->setCantComb($operacion->getCombustibleExistencia());

                    $em->flush();

                    $this->admin->update($operacion);

                    $operacCertif
//                ->setOperacSinCarga(1)
                        ->setOperacConCarga($operacCertif->getOperacConCarga()+1)
//                ->setHorasSinCarga($operacion->getTiempoTrabajado())
                        ->setHorasConCarga($operacCertif->getHorasConCarga()+$operacion->getTiempoTrabajado())
                        ->setEnergiaGenerada($operacCertif->getEnergiaGenerada()+$operacion->getEnergiaGenerada())
//                ->setCombustSinCarga($operacion->getCombustibleConsumido())
                        ->setCombustConCarga($operacCertif->getCombustConCarga()+$operacion->getCombustibleConsumido())
                    ;
//        $em->persist($certf);
                    $em->flush();
                }
            }


            $this->addFlash('sonata_flash_success', 'Operación validada Satisfactoriamente');
            return new RedirectResponse($this->admin->generateUrl('list'));


        }

///////////
//        $this->addFlash('sonata_flash_success', 'Operación validada Satisfactoriamente');


    }

//    public function estadoValidada($varid)
//    {
//
//        $operacion = $this->admin->getObject($varid);
//
//        $em = $this->getDoctrine()->getManager();
//        $estadoOpSinValid=$em->getRepository('SigigeeBundle:EstadoOperacion')->findOneBy(array('nombre'=>'Sin Validar'));
//        $estadoOpDespreci=$em->getRepository('SigigeeBundle:EstadoOperacion')->findOneBy(array('nombre'=>'Despreciada'));
//        if($operacion->getEstadoOperacion()==$estadoOpSinValid or $operacion->getEstadoOperacion()==$estadoOpDespreci)
//        {
//            return true;
//        }
//        else return false;
//
//    }

    public function batchActionValidarIsRelevant(array $selectedIds, $allEntitiesSelected)//validación de ser posible realizar la accion Validar
    {
//      devolver lo siguiente:
//*  true: The batch action is relevant and can be applied.
//• false: Same as above, with the default “action aborted, no model selected” notification message.
//• a string: The batch action is not relevant given the current request parameters (for example the target is
//missing for a merge action). The returned string is a message displayed to the user.

//        // here you have access to all POST parameters, if you use some custom ones
//        // POST parameters are kept even after the confirmation page.
        $parameterBag = $this->get('request')->request;
//
//        // check that a target has been chosen
//        if (!$parameterBag->has('targetId')){return 'flash_batch_merge_no_target';}
//
//        $targetId = $parameterBag->get('targetId');
//
        // if all entities are selected, a merge can be done
        if ($allEntitiesSelected) {
            return 'Todas las operaciones existentes no se pueden validar!!';
        }

//        throw new \Exception(print_r($selectedIds));
//        throw new \Exception(print_r($targetId));
//        throw new \Exception(print_r(array_filter($selectedIds, $this->estadoValidada($targetId))));

        $em = $this->getDoctrine()->getManager();
        foreach ($selectedIds as $id)
        {
            $operacion = $this->admin->getObject($id);    //asi no coge las propiedades automaticamente
//            $operacion = $em->getRepository('SigigeeBundle:RegistroOperacion')->find($id);
            $estadoOpValid = $em->getRepository('SigigeeBundle:EstadoOperacion')->findOneBy(array('nombre' => 'Validada'));

            if ($operacion->getEstadoOperacion() == $estadoOpValid) {
                return 'La operación con fecha: '.$operacion->getDia()->format('d/m/Y'). ' y GEE: '.$operacion->getGee().', perteneciente a '.$operacion->getGee()->getEntidad().' ya está validada!!';
            }


        }

        return count($selectedIds) > 0;
    }

    public function batchActionValidar(ProxyQueryInterface $selectedModelQuery)//logica que se ejecuta al dar Validar abajo
    {
        if (!$this->admin->isGranted('EDIT')){ throw new AccessDeniedException(); } //verifico si puede modificar

        $request = $this->get('request');
        $modelManager = $this->admin->getModelManager();
//        $target = $modelManager->find($this->admin->getClass(), $request->get('targetId'));

        //INTERESANTE COMO AQUI SE REDIRECCIONA CON FILTORS APLICADOS Y TODO
//        if( $target === null)
//        {
//            $this->addFlash('sonata_flash_info', 'flash_batch_merge_no_target');
//            return new RedirectResponse($this->admin->generateUrl(’list’,$this->admin->getFilterParameters())
//);
        $selectedModels = $selectedModelQuery->execute();
//        // do the merge work here
        $operacionesvalidadas=array();
        try
        {
            foreach ($selectedModels as $selectedModel)
            {
                //aqui tengo que hacer el update 000000000000 tengo que hacerlo con la logica de validarButton////////////////////////////////
//                $modelManager->delete($selectedModel);






                $em=$this->getDoctrine()->getManager();
                $operacion=$em->getRepository('SigigeeBundle:RegistroOperacion')->find($selectedModel);
                $operacion->setEstadoOperacion($em->getRepository('SigigeeBundle:EstadoOperacion')->findOneBy(array('nombre' => 'Validada')));
                $em->flush();
                $operacionesvalidadas[]='Fecha: '.$operacion->getDia()->format('d/M/Y').'   GEE: '.$operacion->getGee()."\n";
//                $this->addFlash('sonata_flash_success', 'Operación validar realizada satisfactoriamente a los elementos seleccionados '.$operacion->getDia()->format('d/M/Y').$operacion->getGee());
            }
            $strops="";
            foreach($operacionesvalidadas as $op)
            {$strops=$op."\n";}
            $this->addFlash('sonata_flash_success', "Operación validar realizada satisfactoriamente a los siguientes elementos: \n".$strops);
            return new RedirectResponse($this->admin->generateUrl('list',$this->admin->getFilterParameters()));
        } catch (\Exception $e) {
            $this->addFlash('sonata_flash_error', $e->getMessage());
            return new RedirectResponse($this->admin->generateUrl('list',$this->admin->getFilterParameters()));
            }
//        $this->addFlash('sonata_flash_success', 'flash_batch_merge_success');
//        throw new \Exception(print_r($selectedModels));
//        return new RedirectResponse($this->admin->generateUrl('list',$this->admin->getFilterParameters()));
//        throw new \Exception(print_r($selectedModels));
    }
}
