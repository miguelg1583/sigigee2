<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 02/01/17
 * Time: 06:05 PM
 */

namespace SigigeeBundle\DataFixtures\ORM;


use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use SigigeeBundle\Entity;

class Load extends AbstractFixture implements OrderedFixtureInterface
{

    /**
     * Load data fixtures with the passed EntityManager
     *
     * @param ObjectManager $manager
     */
    public function load(ObjectManager $manager)
    {



//        Provicias
        $provincias=array();
        $provincias[]="Pinar del Rio";
        $provincias[]="Artemisa";
        $provincias[]="Mayabeque";
        $provincias[]="La Habana";
        $provincias[]="Matanzas";
        $provincias[]="Villa Clara";
        $provincias[]="Cienfuegos";
        $provincias[]="Sancti Spiritus";
        $provincias[]="Ciego de Avila";
        $provincias[]="Camaguey";
        $provincias[]="Las Tunas";
        $provincias[]="Holguin";
        $provincias[]="Granma";
        $provincias[]="Santiago de Cuba";
        $provincias[]="Guantanamo";
        $provincias[]="Isla de la Juventud";

        foreach($provincias as $nbProvincia)
        {
            $provincia=new Entity\Provincia();
            $provincia->setNombre($nbProvincia);
            if($nbProvincia=="La Habana")$this->addReference('provHabana',$provincia);
            $manager->persist($provincia);
        }
        $manager->flush();

//        Municipios de La Habana
        $municipios=array();
        $municipios[]="Centro Habana";
        $municipios[]="Habana Vieja";
        $municipios[]="Habana del Este";
        $municipios[]="Alamar";
        $municipios[]="Guanabacoa";
        $municipios[]="San Miguel del Padron";
        $municipios[]="Cotorro";
        $municipios[]="Boyeros";
        $municipios[]="Playa";
        $municipios[]="Plaza de la Revolucion";
        $municipios[]="10 de Octubre";
        $municipios[]="Lisa";
        $municipios[]="Regla";
        $municipios[]="Cerro";

        //$provLaHabana=$manager->getRepository('UEBGEESigigeeBundle:Provincia')->findOneBy(array('nombre'=>'La Habana'));

        foreach($municipios as $nbMunicipio)
        {
            $municipio=new Entity\Municipio();
            $municipio->setNombre($nbMunicipio);
            $municipio->setProvincia($this->getReference('provHabana'));
            $manager->persist($municipio);
        }
        $manager->flush();

//        Nomenclador Unidad de Medida
        $unidadesMedidas=array(
            "Voltaje"=>array(
                "notacion"=>"V",
                "descripcion"=>"Tension/Volt"
            ),
            "Amperaje"=>array(
                "notacion"=>"A",
                "descripcion"=>"Corriente/Amperes"
            ),
            "Wattaje"=>array(
                "notacion"=>"W",
                "descripcion"=>"Potencia/Watt"
            ),
            "Longitud"=>array(
                "notacion"=>"m",
                "descripcion"=>"Metros"
            ),
            "Peso"=>array(
                "notacion"=>"Kg",
                "descripcion"=>"Kilogramos"
            )
        );

        foreach ($unidadesMedidas as $ref => $info) {
            $nomUM = new Entity\NomUnidadMedida();
            foreach ($info as $atributo => $valor) {
                $nomUM->{"set".ucfirst($atributo)}($valor);
            }
            if($nomUM->getDescripcion()=="Tension/Volt")$this->addReference('UMVoltaje',$nomUM);

            $manager->persist($nomUM);
        }

        $manager->flush();

//        Nomenclador Voltaje
        $voltajes=array();
        $voltajes[]="480 / 277";
        $voltajes[]="480 / 227";
        $voltajes[]="440 / 277";
        $voltajes[]="440 / 227";
        $voltajes[]="240 / 120";
        $voltajes[]="220 / 127";
        $voltajes[]="220 / 110";
        $voltajes[]="400 / 231";
        $voltajes[]="480 / 231";

        foreach($voltajes as $voltaje)
        {
            $nomVoltaje=new Entity\NomVoltaje();
            $nomVoltaje->setUnidadMedida($this->getReference('UMVoltaje'));
            $nomVoltaje->setVoltaje($voltaje);
            $nomVoltaje->setCorriente("Alterna");
            $manager->persist($nomVoltaje);
        }
        $manager->flush();

//        NomMarca
        $marcas=array();
        $marcas[]="DAEWOO";
        $marcas[]="MAGNA PLUS";
        $marcas[]="DENYO";
        $marcas[]="VOLVO";
        $marcas[]="DETROIT";
        $marcas[]="DEUTZ";
        $marcas[]="YANZ";
        $marcas[]="PEGASSO";
        $marcas[]="MINGZ";
        $marcas[]="SAVOIA";
        $marcas[]="YANMAR";
        $marcas[]="DORMAN";
        $marcas[]="SIMSON-MARELLI";
        $marcas[]="ELCOS";
        $marcas[]="ELECTRA MOLINS";
        $marcas[]="WILSON";
        $marcas[]="GENERAL POWER";
        $marcas[]="ISSOTTA FRANCHINI";
        $marcas[]="SCANIA";
        $marcas[]="MITSUBISCHI";
        $marcas[]="JHON RELY";
        $marcas[]="GENERAL ELECTRIC";
        $marcas[]="ISUZU";

        foreach($marcas as $marca)
        {
            $nomMarca=new Entity\NomMarca();
            $nomMarca->setMarca($marca);
            $nomMarca->setProcedencia("Desconocido");
            $manager->persist($nomMarca);
        }
        $manager->flush();

//        Nomenclador Generador
        $generadores=array(
            "Gen1"=>array(
                "nombre"=>"DENYO",
                "modelo"=>"DB-0667I"
            ),
            "Gen2"=>array(
                "nombre"=>"DENYO",
                "modelo"=>"DB-0501I"
            ),
            "Gen3"=>array(
                "nombre"=>"DENYO",
                "modelo"=>"DB-0661H"
            ),
            "Gen4"=>array(
                "nombre"=>"WEG",
                "modelo"=>"GTA-200"
            ),
            "Gen5"=>array(
                "nombre"=>"HEIMER",
                "modelo"=>"ATED40/30"
            ),
            "Gen6"=>array(
                "nombre"=>"HEIMER",
                "modelo"=>"ATED40/38"
            ),
            "Gen7"=>array(
                "nombre"=>"HEIMER",
                "modelo"=>"ATED45/42"
            ),
            "Gen8"=>array(
                "nombre"=>"WEG",
                "modelo"=>"GTA-315"
            ),
            "Gen9"=>array(
                "nombre"=>"DENYO",
                "modelo"=>"DF-0277I"
            ),
            "Gen10"=>array(
                "nombre"=>"DENYO",
                "modelo"=>"DF-0220K"
            )
        );
        foreach ($generadores as $ref => $info) {
            $nomGen = new Entity\NomGenerador();
            foreach ($info as $atributo => $valor) {
                $nomGen->{"set".ucfirst($atributo)}($valor);
            }
            $manager->persist($nomGen);
        }
        $manager->flush();

//        Nomenclador de Motor
        $motores=array(
            "Motor1"=>array(
                "nombre"=>"MB",
                "modelo"=>"OM364A",
                "rpm"=>0,
                "voltaje"=>0,
                "cantBaterias"=>0,
                "aceite"=>"",
            ),
            "Motor2"=>array(
                "nombre"=>"MB",
                "modelo"=>"OM-447A",
                "rpm"=>0,
                "voltaje"=>0,
                "cantBaterias"=>0,
                "aceite"=>"",
            ),
            "Motor3"=>array(
                "nombre"=>"MB",
                "modelo"=>"OM-447LA",
                "rpm"=>0,
                "voltaje"=>0,
                "cantBaterias"=>0,
                "aceite"=>"",
            ),
            "Motor4"=>array(
                "nombre"=>"VOLVO",
                "modelo"=>"TAD1642GE",
                "rpm"=>0,
                "voltaje"=>0,
                "cantBaterias"=>0,
                "aceite"=>"",
            ),
            "Motor5"=>array(
                "nombre"=>"SCANIA",
                "modelo"=>"DC1241A",
                "rpm"=>0,
                "voltaje"=>0,
                "cantBaterias"=>0,
                "aceite"=>"",
            ),
            "Motor6"=>array(
                "nombre"=>"SCANIA",
                "modelo"=>"DC1643A",
                "rpm"=>0,
                "voltaje"=>0,
                "cantBaterias"=>0,
                "aceite"=>"",
            ),
            "Motor7"=>array(
                "nombre"=>"KUBOTA",
                "modelo"=>"D1403",
                "rpm"=>0,
                "voltaje"=>0,
                "cantBaterias"=>0,
                "aceite"=>"",
            ),
            "Motor8"=>array(
                "nombre"=>"HINO",
                "modelo"=>"W04D-TG",
                "rpm"=>0,
                "voltaje"=>0,
                "cantBaterias"=>0,
                "aceite"=>"",
            ),
            "Motor9"=>array(
                "nombre"=>"ISUZO",
                "modelo"=>"AA-4LE2",
                "rpm"=>0,
                "voltaje"=>0,
                "cantBaterias"=>0,
                "aceite"=>"",
            ),
            "Motor10"=>array(
                "nombre"=>"MB",
                "modelo"=>"OM366-LA",
                "rpm"=>0,
                "voltaje"=>0,
                "cantBaterias"=>0,
                "aceite"=>"",
            ),
        );
        foreach ($motores as $ref => $info) {
            $nomMotor = new Entity\NomMotor();
            foreach ($info as $atributo => $valor) {
                $nomMotor->{"set".ucfirst($atributo)}($valor);
            }
            $manager->persist($nomMotor);
        }
        $manager->flush();

//        Nomenclador de GEE
        $umMetros=$manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Metros'));
        $marcas=$manager->getRepository('SigigeeBundle:NomMarca')->findAll();
        $motores=$manager->getRepository('SigigeeBundle:NomMotor')->findAll();
        $generadores=$manager->getRepository('SigigeeBundle:NomGenerador')->findAll();
        $voltajes=$manager->getRepository('SigigeeBundle:NomVoltaje')->findAll();

        $gee=new Entity\NomGee();
        $gee->setModelo("Modelo1");
        $gee->setCorrienteSalida(0);
        $gee->setPotenciaSalida(0);
        $gee->setLargo(0);
        $gee->setAncho(0);
        $gee->setAlto(0);
        $gee->setPeso(0);
        $gee->setCorrienteSalidaUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Corriente/Amperes')));
        $gee->setPotenciaSalidaUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Potencia/Watt')));
        $gee->setLargoUM($umMetros);
        $gee->setAnchoUM($umMetros);
        $gee->setAltoUM($umMetros);
        $gee->setPesoUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Kilogramos')));
        $gee->setMarca($marcas[rand(0,count($marcas)-1)]);
        $gee->setMotor($motores[rand(0,count($motores)-1)]);
        $gee->setGenerador($generadores[rand(0,count($generadores)-1)]);
        $gee->setVoltajeSalida($voltajes[rand(0,count($voltajes)-1)]);

        $manager->persist($gee);

        $gee=new Entity\NomGee();
        $gee->setModelo("Modelo2");
        $gee->setCorrienteSalida(0);
        $gee->setPotenciaSalida(0);
        $gee->setLargo(0);
        $gee->setAncho(0);
        $gee->setAlto(0);
        $gee->setPeso(0);
        $gee->setCorrienteSalidaUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Corriente/Amperes')));
        $gee->setPotenciaSalidaUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Potencia/Watt')));
        $gee->setLargoUM($umMetros);
        $gee->setAnchoUM($umMetros);
        $gee->setAltoUM($umMetros);
        $gee->setPesoUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Kilogramos')));
        $gee->setMarca($marcas[rand(0,count($marcas)-1)]);
        $gee->setMotor($motores[rand(0,count($motores)-1)]);
        $gee->setGenerador($generadores[rand(0,count($generadores)-1)]);
        $gee->setVoltajeSalida($voltajes[rand(0,count($voltajes)-1)]);

        $manager->persist($gee);

        $gee=new Entity\NomGee();
        $gee->setModelo("Modelo3");
        $gee->setCorrienteSalida(0);
        $gee->setPotenciaSalida(0);
        $gee->setLargo(0);
        $gee->setAncho(0);
        $gee->setAlto(0);
        $gee->setPeso(0);
        $gee->setCorrienteSalidaUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Corriente/Amperes')));
        $gee->setPotenciaSalidaUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Potencia/Watt')));
        $gee->setLargoUM($umMetros);
        $gee->setAnchoUM($umMetros);
        $gee->setAltoUM($umMetros);
        $gee->setPesoUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Kilogramos')));
        $gee->setMarca($marcas[rand(0,count($marcas)-1)]);
        $gee->setMotor($motores[rand(0,count($motores)-1)]);
        $gee->setGenerador($generadores[rand(0,count($generadores)-1)]);
        $gee->setVoltajeSalida($voltajes[rand(0,count($voltajes)-1)]);

        $manager->persist($gee);

        $gee=new Entity\NomGee();
        $gee->setModelo("Modelo4");
        $gee->setCorrienteSalida(0);
        $gee->setPotenciaSalida(0);
        $gee->setLargo(0);
        $gee->setAncho(0);
        $gee->setAlto(0);
        $gee->setPeso(0);
        $gee->setCorrienteSalidaUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Corriente/Amperes')));
        $gee->setPotenciaSalidaUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Potencia/Watt')));
        $gee->setLargoUM($umMetros);
        $gee->setAnchoUM($umMetros);
        $gee->setAltoUM($umMetros);
        $gee->setPesoUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Kilogramos')));
        $gee->setMarca($marcas[rand(0,count($marcas)-1)]);
        $gee->setMotor($motores[rand(0,count($motores)-1)]);
        $gee->setGenerador($generadores[rand(0,count($generadores)-1)]);
        $gee->setVoltajeSalida($voltajes[rand(0,count($voltajes)-1)]);

        $manager->persist($gee);

        $gee=new Entity\NomGee();
        $gee->setModelo("Modelo5");
        $gee->setCorrienteSalida(0);
        $gee->setPotenciaSalida(0);
        $gee->setLargo(0);
        $gee->setAncho(0);
        $gee->setAlto(0);
        $gee->setPeso(0);
        $gee->setCorrienteSalidaUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Corriente/Amperes')));
        $gee->setPotenciaSalidaUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Potencia/Watt')));
        $gee->setLargoUM($umMetros);
        $gee->setAnchoUM($umMetros);
        $gee->setAltoUM($umMetros);
        $gee->setPesoUM($manager->getRepository('SigigeeBundle:NomUnidadMedida')->findOneBy(array('descripcion'=>'Kilogramos')));
        $gee->setMarca($marcas[rand(0,count($marcas)-1)]);
        $gee->setMotor($motores[rand(0,count($motores)-1)]);
        $gee->setGenerador($generadores[rand(0,count($generadores)-1)]);
        $gee->setVoltajeSalida($voltajes[rand(0,count($voltajes)-1)]);

        $manager->persist($gee);

        $manager->flush();

//        Ministerio
        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINEM");
        $ministerio->setNombre("Ministerio de Energia y Minas");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINDUS");
        $ministerio->setNombre("Ministerio de Industrias");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINAG");
        $ministerio->setNombre("Ministerio de la Agricultura");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("CITMA");
        $ministerio->setNombre("Ministerio de Ciencia, Tecnología y Medio Ambiente");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINCI");
        $ministerio->setNombre("Ministerio de Comercio Interior");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MIC");
        $ministerio->setNombre("Ministerio de Informatica y Comunicaciones");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MICON");
        $ministerio->setNombre("Ministerio de la Contruccion");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINCULT");
        $ministerio->setNombre("Ministerio de Cultura");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MEP");
        $ministerio->setNombre("Ministerio de Economia y Planificacion");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINED");
        $ministerio->setNombre("Ministerio de Educacion");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MES");
        $ministerio->setNombre("Ministerio de Educacion Superior");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MFP");
        $ministerio->setNombre("Ministerio de Finanzas y Precios");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINFAR");
        $ministerio->setNombre("Ministerio de las Fuerzas Armadas Revolucionarias");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINAL");
        $ministerio->setNombre("Ministerio de la Industria Alimentaria");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MININT");
        $ministerio->setNombre("Ministerio del Interior");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINJUS");
        $ministerio->setNombre("Ministerio de Justicia");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINREX");
        $ministerio->setNombre("Ministerio de Relaciones Exteriores");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MTSS");
        $ministerio->setNombre("Ministerio del Trabajo y Seguridad Social");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINSAP");
        $ministerio->setNombre("Ministerio de Salud Publica");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MITRANS");
        $ministerio->setNombre("Ministerio del Transporte");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINTUR");
        $ministerio->setNombre("Ministerio del Turismo");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("MINCEX");
        $ministerio->setNombre("Ministerio del Comercio Exterior y la Inversion Extranjera");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("BCC");
        $ministerio->setNombre("Banco Central de Cuba");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("ICRT");
        $ministerio->setNombre("Instituto Cubano de Radio y Television");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("INRH");
        $ministerio->setNombre("Instituto Nacional de Recursos Hidraulicos");
        $manager->persist($ministerio);

        $ministerio=new Entity\Ministerio();
        $ministerio->setSiglas("INDER");
        $ministerio->setNombre("Instituto Nacional de Deportes, Educacion Fisica y Recreacion");
        $manager->persist($ministerio);

        $manager->flush();


    }

    /**
     * Get the order of this fixture
     *
     * @return integer
     */
    public function getOrder()
    {

        return 1;
    }
}