<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 04/01/17
 * Time: 11:37 PM
 */

namespace SigigeeBundle\DataFixtures\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use SigigeeBundle\Entity;

class Load2 extends AbstractFixture implements OrderedFixtureInterface
{

    /**
     * Load data fixtures with the passed EntityManager
     *
     * @param ObjectManager $manager
     */
    public function load(ObjectManager $manager)
    {
        // TODO: Implement load() method.
        //Entidad
//        $this->getReference('provHabana')=$manager->getRepository("SigigeeBundle:Provincia")->findOneBy(array('nombre'=>'La Habana'));
        $entidades=array(
            "entidad1"=>array("nombre"=>"CUBANACAN", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINTUR')), "direccion"=>"146A Nº907 e/ 9na Y 9naA", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Playa'))),
            "entidad2"=>array("nombre"=>"BANCO METROPOLITANO DIRECCION DE SERVICIOS GENERALES", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'BCC')), "direccion"=>"VELAZQUEZ s/n  FABRICA Y REFORMA LUYANO", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'10 de Octubre'))),
            "entidad3"=>array("nombre"=>"AEROPUERTO JOSE MARTI TERMINAL 1", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MITRANS')), "direccion"=>"VAN TROI y FINAL", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Boyeros'))),
            "entidad4"=>array("nombre"=>"PALMARES RESTAURANTES", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINCI')), "direccion"=>"13Nº18006 e/ 5ta y 184 Siboney", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Playa'))),
            "entidad5"=>array("nombre"=>"CARDIOCENTRO WILLIAM SOLER", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINSAP')), "direccion"=>"Calle Perla y 100", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Boyeros'))),
            "entidad6"=>array("nombre"=>"CLINICA CIRA GARCIA", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINSAP')), "direccion"=>"Calle 41 esq 20", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Plaza de la Revolucion'))),
            "entidad7"=>array("nombre"=>"COPPELIA", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINCI')), "direccion"=>"CALLE 10 Nº 506 e/ 5ta Y 31", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Plaza de la Revolucion'))),
            "entidad8"=>array("nombre"=>"DATYS", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MININT')), "direccion"=>"1ra e/4 y 6", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Playa'))),
            "entidad9"=>array("nombre"=>"DIRECCION PROVINCIAL DE EDUCACION", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINED')), "direccion"=>"CALLE 22 e/ 1ra Y 3ra", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Playa'))),
            "entidad10"=>array("nombre"=>"FRIGORIFICO CARLOS III", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINCI')), "direccion"=>"ESTRELLA 771 E/ ARBOL SECO Y RETIRO", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Centro Habana'))),
            "entidad11"=>array("nombre"=>"HAVANATUR", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINTUR')), "direccion"=>"Calle 2 e/. 1ra y 3ra", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Playa'))),
            "entidad12"=>array("nombre"=>"INMIGRACION Y EXTRANJERIA", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MININT')), "direccion"=>"22 E/5TA AVE Y 3RA", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Playa'))),
            "entidad13"=>array("nombre"=>"SERVAC", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MITRANS')), "direccion"=>"23 / P y Malecon", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Plaza de la Revolucion'))),
            "entidad14"=>array("nombre"=>"UM-9058", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINFAR')), "direccion"=>"36 entre 39 y Kholy", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Plaza de la Revolucion'))),
            "entidad15"=>array("nombre"=>"UNIVERSIDAD DE LA HABANA", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MES')), "direccion"=>"L y 21", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Plaza de la Revolucion'))),
            "entidad16"=>array("nombre"=>"EMPRESA DE CAMIONES NARCISO LOPEZ ROSELLO", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINDUS')), "direccion"=>"Wajay", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Boyeros'))),
            "entidad17"=>array("nombre"=>"INSTITUTO DE DESARROLLO AUTOMOTOR", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'MINDUS')), "direccion"=>"Van Troi", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>'Boyeros'))),
//            "entidad1"=>array("nombre"=>"", "entidadSuperior"=>null, "ministerio"=>$manager->getRepository("SigigeeBundle:Ministerio")->findOneBy(array('siglas'=>'')), "direccion"=>"", "provincia"=>$this->getReference('provHabana'), "municipio"=>$manager->getRepository("SigigeeBundle:Municipio")->findOneBy(array('nombre'=>''))),
        );
        foreach ($entidades as $ref => $info) {
            $entidad = new Entity\Entidad();
            foreach ($info as $atributo => $valor) {
                $entidad->{"set".ucfirst($atributo)}($valor);
            }
            $manager->persist($entidad);
        }
        $manager->flush();

        //EstadoGee
        $estadoGee= new Entity\EstadoGee();
        $estadoGee->setNombre('OK');
        $manager->persist($estadoGee);
        $estadoGee->setNombre('Fuera de Servicio');
        $manager->persist($estadoGee);
        $estadoGee->setNombre('Sin Combustible');
        $manager->persist($estadoGee);
        $manager->flush();

        //Existencia GEE
        $entidades = $manager->getRepository("SigigeeBundle:Entidad")->findAll();
        $nomgees = $manager->getRepository("SigigeeBundle:NomGee")->findAll();
//        $fecha=getdate();
        $estado = $manager->getRepository("SigigeeBundle:EstadoGee")->findAll();
        foreach ($entidades as $entidadpos) {
            $existenciagee= new Entity\ExistenciaGee();
            $doblegee=rand(1,2);
            if ($doblegee==1) {
                $existenciagee->setTipoGee($nomgees[rand(0, count($nomgees) - 1)]);
                $existenciagee->setEntidad($entidadpos);
                $existenciagee->setNoInventario("CH" . (string)rand(1000, 9999));
                $existenciagee->setFechaEntrada(new \DateTime());
                $existenciagee->setEstado($estado[rand(0,count($estado)-1)]);
                $manager->persist($existenciagee);
            }
            if ($doblegee==2){
                $existenciagee->setTipoGee($nomgees[rand(0,count($nomgees)-1)]);
                $existenciagee->setEntidad($entidadpos);
                $existenciagee->setNoInventario("CH".(string)rand(1000,9999));
                $existenciagee->setFechaEntrada(new \DateTime());
                $existenciagee->setEstado($estado[rand(0,count($estado)-1)]);
                $manager->persist($existenciagee);

                $existenciagee->setTipoGee($nomgees[rand(0,count($nomgees)-1)]);
                $existenciagee->setEntidad($entidadpos);
                $existenciagee->setNoInventario("CH".(string)rand(1000,9999));
                $existenciagee->setFechaEntrada(new \DateTime());
                $existenciagee->setEstado($estado[rand(0,count($estado)-1)]);
                $manager->persist($existenciagee);
            }
            $manager->flush();

        }
    }

    /**
     * Get the order of this fixture
     *
     * @return integer
     */
    public function getOrder()
    {
        // TODO: Implement getOrder() method.
        return 2;
    }
}