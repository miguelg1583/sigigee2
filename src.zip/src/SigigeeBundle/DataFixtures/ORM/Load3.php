<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 15/01/17
 * Time: 07:18 PM
 */

namespace SigigeeBundle\DataFixtures\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use SigigeeBundle\Entity;

class Load3 extends AbstractFixture implements OrderedFixtureInterface
{

    /**
     * Load data fixtures with the passed EntityManager
     *
     * @param ObjectManager $manager
     */
    public function load(ObjectManager $manager)
    {
        //TipoDistribucion
        $tipoDistribucion= new Entity\TipoDistribucion();
        $tipoDistribucion
            ->setSigla('TD')
            ->setNombre('Tiro Directo');
        $manager->persist($tipoDistribucion);
        $tipoDistribucion
            ->setSigla('TM')
            ->setNombre('Tarjeta Magnética');
        $manager->persist($tipoDistribucion);
        $manager->flush();

        //EstadoAprobacion
        $estadoAprobacion= new Entity\EstadoAprobacion();
        $estadoAprobacion
            ->setNombre('Si');
        $manager->persist($estadoAprobacion);
        $estadoAprobacion
            ->setNombre('No');
        $manager->persist($estadoAprobacion);
        $estadoAprobacion
            ->setNombre('Pendiente');
        $manager->persist($estadoAprobacion);
        $manager->flush();

        //ConceptoAprobComb
        $conceptoAprobComb= new Entity\ConceptoAprobComb();
        $conceptoAprobComb
            ->setNombre('Primer Llenado');
        $manager->persist($conceptoAprobComb);
        $conceptoAprobComb
            ->setNombre('Por Operaciones');
        $manager->persist($conceptoAprobComb);
        $manager->flush();

        //TipoOperacion
        $tipoOperacion= new Entity\TipoOperacion();
        $tipoOperacion
            ->setSigla('IA')
            ->setNombre('Operación por Interrupción o Avería en el servicio eléctrico');
        $manager->persist($tipoOperacion);
        $tipoOperacion
            ->setSigla('LD')
            ->setNombre('Operación de Liberación de Demanda por Orden de la DGE UNE');
        $manager->persist($tipoOperacion);
        $tipoOperacion
            ->setSigla('SS')
            ->setNombre('Operación de Sincronización al SEN por Orden del DNC');
        $manager->persist($tipoOperacion);
        $tipoOperacion
            ->setSigla('PS')
            ->setNombre('Operación sin carga para dar mantenimiento a las baterías y comprobar la disponibilidad del GEE');
        $manager->persist($tipoOperacion);
        $tipoOperacion
            ->setSigla('IU')
            ->setNombre('Operación ocurrida por trabajos de rehabilitación de líneas, vías libres u alguno otra operación en las líneas que provoque el trabajo de los GEE');
        $manager->persist($tipoOperacion);
        $tipoOperacion
            ->setSigla('PC')
            ->setNombre('Operación realizada con carga para comprobar los parámetros del GEE y la disponibilidad del GEE ante la falta de servicio eléctrico');
        $manager->persist($tipoOperacion);
        $tipoOperacion
            ->setSigla('LC')
            ->setNombre('Prueba del Litros con Carga');
        $manager->persist($tipoOperacion);
        $tipoOperacion
            ->setSigla('LS')
            ->setNombre('Prueba del Litros sin Carga');
        $manager->persist($tipoOperacion);
        $manager->flush();

        //EstadoOperacion
        $estadoOperacion= new Entity\EstadoOperacion();
        $estadoOperacion
            ->setNombre('Sin Validar');
        $manager->persist($estadoOperacion);
        $estadoOperacion
            ->setNombre('Validada');
        $manager->persist($estadoOperacion);
        $estadoOperacion
            ->setNombre('Despreciada');
        $manager->persist($estadoOperacion);
        $manager->flush();

        //EstadoCertificacion
        $estadoCertificacion= new Entity\EstadoCertificacion();
        $estadoCertificacion
            ->setNombre('Sin Certificar');
        $manager->persist($estadoCertificacion);
        $estadoCertificacion
            ->setNombre('Certificado');
        $manager->persist($estadoCertificacion);
        $estadoCertificacion
            ->setNombre('Descertificado');
        $manager->persist($estadoCertificacion);
        $manager->flush();
    }

    /**
     * Get the order of this fixture
     *
     * @return integer
     */
    public function getOrder()
    {
        return 3;
    }
}