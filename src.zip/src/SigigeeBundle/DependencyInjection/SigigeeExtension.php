<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 09/09/16
 * Time: 10:34 AM
 */

namespace SigigeeBundle\DependencyInjection;

use Symfony\Component\HttpKernel\DependencyInjection\Extension;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Loader;
use Symfony\Component\Config\FileLocator;

class SigigeeExtension extends Extension
{
    public function load(array $configs, ContainerBuilder $container)
    {
        // ... you'll load the files here later
        $loader = new Loader\YamlFileLoader($container, new FileLocator(__DIR__.'/../Resources/config'));
        $loader->load('services.yml');
        $loader->load('admin.yml');
//        $loader->load('trazas.yml');
//        $loader->load('user_admin.yml');
    }
}