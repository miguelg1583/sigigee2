<?php

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * AprobLlenadoInicial
 *
 * @ORM\Table(name="aprob_llenado_inicial")
 * @ORM\Entity(repositoryClass="SigigeeBundle\Repository\AprobLlenadoInicialRepository")
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class AprobLlenadoInicial
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @ORM\OneToOne(targetEntity="SigigeeBundle\Entity\SolicCombLlenadoInicial")
     */
    private $solicitud;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\EstadoAprobacion")
     */
    private $aprobado;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="fechaAprobacion", type="date")
     */
    private $fechaAprobacion;

    /**
     * @var int
     *
     * @ORM\Column(name="noCartaAprobacion", type="integer")
     */
    private $noCartaAprobacion;

    /**
     * @var int
     *
     * @ORM\Column(name="noOrdenDistribucion", type="integer")
     */
    private $noOrdenDistribucion;

    /**
     * @var string
     *
     * @ORM\Column(name="observaciones", type="string", length=255, nullable=true)
     */
    private $observaciones;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set solicitud
     *
     * @param SolicCombLlenadoInicial $solicitud
     *
     * @return AprobLlenadoInicial
     */
    public function setSolicitud($solicitud)
    {
        $this->solicitud = $solicitud;

        return $this;
    }

    /**
     * Get solicitud
     *
     * @return SolicCombLlenadoInicial
     */
    public function getSolicitud()
    {
        return $this->solicitud;
    }

    /**
     * Set fechaAprobacion
     *
     * @param \DateTime $fechaAprobacion
     *
     * @return AprobLlenadoInicial
     */
    public function setFechaAprobacion($fechaAprobacion)
    {
        $this->fechaAprobacion = $fechaAprobacion;

        return $this;
    }

    /**
     * Get fechaAprobacion
     *
     * @return \DateTime
     */
    public function getFechaAprobacion()
    {
        return $this->fechaAprobacion;
    }

    /**
     * Set noCartaAprobacion
     *
     * @param integer $noCartaAprobacion
     *
     * @return AprobLlenadoInicial
     */
    public function setNoCartaAprobacion($noCartaAprobacion)
    {
        $this->noCartaAprobacion = $noCartaAprobacion;

        return $this;
    }

    /**
     * Get noCartaAprobacion
     *
     * @return int
     */
    public function getNoCartaAprobacion()
    {
        return $this->noCartaAprobacion;
    }

    /**
     * Set noOrdenDistribucion
     *
     * @param integer $noOrdenDistribucion
     *
     * @return AprobLlenadoInicial
     */
    public function setNoOrdenDistribucion($noOrdenDistribucion)
    {
        $this->noOrdenDistribucion = $noOrdenDistribucion;

        return $this;
    }

    /**
     * Get noOrdenDistribucion
     *
     * @return int
     */
    public function getNoOrdenDistribucion()
    {
        return $this->noOrdenDistribucion;
    }

    /**
     * Set observaciones
     *
     * @param string $observaciones
     *
     * @return AprobLlenadoInicial
     */
    public function setObservaciones($observaciones)
    {
        $this->observaciones = $observaciones;

        return $this;
    }

    /**
     * Get observaciones
     *
     * @return string
     */
    public function getObservaciones()
    {
        return $this->observaciones;
    }

    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return AprobLlenadoInicial
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }

    /**
     * Set aprobado
     *
     * @param \SigigeeBundle\Entity\EstadoAprobacion $aprobado
     *
     * @return AprobLlenadoInicial
     */
    public function setAprobado(\SigigeeBundle\Entity\EstadoAprobacion $aprobado = null)
    {
        $this->aprobado = $aprobado;

        return $this;
    }

    /**
     * Get aprobado
     *
     * @return \SigigeeBundle\Entity\EstadoAprobacion
     */
    public function getAprobado()
    {
        return $this->aprobado;
    }
}
