<?php

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * AsignacionComb
 *
 * @ORM\Table(name="asignacion_comb")
 * @ORM\Entity(repositoryClass="SigigeeBundle\Repository\AsignacionCombRepository")
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class AsignacionComb
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Provincia")
     */
    private $provincia;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Entidad")
     */
    private $entidad;

    /**
     * @ORM\OneToOne(targetEntity="SigigeeBundle\Entity\ExistenciaGee")
     */
    private $gee;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\TipoDistribucion")
     */
    private $tipoDistribucion;

    /**
     * @var string
     *
     * @ORM\Column(name="combustible", type="float")
     */
    private $combustible;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="fechaSolic", type="date")
     */
    private $fechaSolic;


    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fechaSolic
     *
     * @param \DateTime $fechaSolic
     *
     * @return AsignacionComb
     */
    public function setFechaSolic($fechaSolic)
    {
        $this->fechaSolic = $fechaSolic;

        return $this;
    }

    /**
     * Get fechaSolic
     *
     * @return \DateTime
     */
    public function getFechaSolic()
    {
        return $this->fechaSolic;
    }

    /**
     * Set combustible
     *
     * @param float $combustible
     *
     * @return AsignacionComb
     */
    public function setCombustible($combustible)
    {
        $this->combustible = $combustible;

        return $this;
    }

    /**
     * Get combustible
     *
     * @return float
     */
    public function getCombustible()
    {
        return $this->combustible;
    }

    /**
     * Set deleteAt
     *
     * @param \DateTime $deletedAt
     *
     * @return AsignacionComb
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deleteAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }

    /**
     * Set provincia
     *
     * @param Provincia $provincia
     *
     * @return AsignacionComb
     */
    public function setProvincia(Provincia $provincia = null)
    {
        $this->provincia = $provincia;

        return $this;
    }

    /**
     * Get provincia
     *
     * @return Provincia
     */
    public function getProvincia()
    {
        return $this->provincia;
    }

    /**
     * Set entidad
     *
     * @param Entidad $entidad
     *
     * @return AsignacionComb
     */
    public function setEntidad(Entidad $entidad = null)
    {
        $this->entidad = $entidad;

        return $this;
    }

    /**
     * Get entidad
     *
     * @return Entidad
     */
    public function getEntidad()
    {
        return $this->entidad;
    }

    /**
     * Set gee
     *
     * @param ExistenciaGee $gee
     *
     * @return AsignacionComb
     */
    public function setGee(ExistenciaGee $gee = null)
    {
        $this->gee = $gee;

        return $this;
    }

    /**
     * Get gee
     *
     * @return ExistenciaGee
     */
    public function getGee()
    {
        return $this->gee;
    }

//    /**
//     * Set estadoAprob
//     *
//     * @param EstadoAprobacion $estadoAprob
//     *
//     * @return AsignacionComb
//     */
//    public function setEstadoAprob(EstadoAprobacion $estadoAprob = null)
//    {
//        $this->estadoAprob = $estadoAprob;
//
//        return $this;
//    }
//
//    /**
//     * Get estadoAprob
//     *
//     * @return EstadoAprobacion
//     */
//    public function getEstadoAprob()
//    {
//        return $this->estadoAprob;
//    }



    /**
     * Set tipoDistribucion
     *
     * @param TipoDistribucion $tipoDistribucion
     *
     * @return AsignacionComb
     */
    public function setTipoDistribucion(TipoDistribucion $tipoDistribucion = null)
    {
        $this->tipoDistribucion = $tipoDistribucion;

        return $this;
    }

    /**
     * Get tipoDistribucion
     *
     * @return TipoDistribucion
     */
    public function getTipoDistribucion()
    {
        return $this->tipoDistribucion;
    }

    function __toString()
    {
        return $this->getEntidad().' '.$this->getCombustible().' '.$this->getGee();
    }


}
