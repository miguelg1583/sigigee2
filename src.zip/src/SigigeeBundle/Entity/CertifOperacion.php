<?php

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * CertifOperacion
 *
 * @ORM\Table(name="certif_operacion")
 * @ORM\Entity(repositoryClass="SigigeeBundle\Repository\CertifOperacionRepository")
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class CertifOperacion
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @ORM\Column(name="mes", type="integer", nullable=true)
     */
    private $mes;

    /**
     * @ORM\Column(name="anno", type="integer", nullable=true)
     */
    private $anno;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\ExistenciaGee")
     */
    private $gee;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Municipio")
     */
    private $municipio;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Entidad")
     */
    private $centro;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomMarca")
     */
    private $marca;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomVoltaje")
     */
    private $kvaVoltajeSalida;

    /**
     * @var int
     *
     * @ORM\Column(name="operacSinCarga", type="integer", nullable=true)
     */
    private $operacSinCarga;

    /**
     * @var int
     *
     * @ORM\Column(name="operacConCarga", type="integer", nullable=true)
     */
    private $operacConCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="horasSinCarga", type="float", nullable=true)
     */
    private $horasSinCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="horasConCarga", type="float", nullable=true)
     */
    private $horasConCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="energiaGenerada", type="float", nullable=true)
     */
    private $energiaGenerada;

    /**
     * @var float
     *
     * @ORM\Column(name="combustSinCarga", type="float", nullable=true)
     */
    private $combustSinCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="combustConCarga", type="float", nullable=true)
     */
    private $combustConCarga;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\EstadoCertificacion")
     */
    private $estadoCertificacion;

    function __toString()
    {
        return $this->getId().''.$this->getGee();

    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set operacSinCarga
     *
     * @param integer $operacSinCarga
     *
     * @return CertifOperacion
     */
    public function setOperacSinCarga($operacSinCarga)
    {
        $this->operacSinCarga = $operacSinCarga;

        return $this;
    }

    /**
     * Get operacSinCarga
     *
     * @return int
     */
    public function getOperacSinCarga()
    {
        return $this->operacSinCarga;
    }

    /**
     * Set operacConCarga
     *
     * @param integer $operacConCarga
     *
     * @return CertifOperacion
     */
    public function setOperacConCarga($operacConCarga)
    {
        $this->operacConCarga = $operacConCarga;

        return $this;
    }

    /**
     * Get operacConCarga
     *
     * @return int
     */
    public function getOperacConCarga()
    {
        return $this->operacConCarga;
    }

    /**
     * Set horasSinCarga
     *
     * @param float $horasSinCarga
     *
     * @return CertifOperacion
     */
    public function setHorasSinCarga($horasSinCarga)
    {
        $this->horasSinCarga = $horasSinCarga;

        return $this;
    }

    /**
     * Get horasSinCarga
     *
     * @return float
     */
    public function getHorasSinCarga()
    {
        return $this->horasSinCarga;
    }

    /**
     * Set horasConCarga
     *
     * @param float $horasConCarga
     *
     * @return CertifOperacion
     */
    public function setHorasConCarga($horasConCarga)
    {
        $this->horasConCarga = $horasConCarga;

        return $this;
    }

    /**
     * Get horasConCarga
     *
     * @return float
     */
    public function getHorasConCarga()
    {
        return $this->horasConCarga;
    }

    /**
     * Set energiaGenerada
     *
     * @param float $energiaGenerada
     *
     * @return CertifOperacion
     */
    public function setEnergiaGenerada($energiaGenerada)
    {
        $this->energiaGenerada = $energiaGenerada;

        return $this;
    }

    /**
     * Get energiaGenerada
     *
     * @return float
     */
    public function getEnergiaGenerada()
    {
        return $this->energiaGenerada;
    }

    /**
     * Set combustSinCarga
     *
     * @param float $combustSinCarga
     *
     * @return CertifOperacion
     */
    public function setCombustSinCarga($combustSinCarga)
    {
        $this->combustSinCarga = $combustSinCarga;

        return $this;
    }

    /**
     * Get combustSinCarga
     *
     * @return float
     */
    public function getCombustSinCarga()
    {
        return $this->combustSinCarga;
    }

    /**
     * Set combustConCarga
     *
     * @param float $combustConCarga
     *
     * @return CertifOperacion
     */
    public function setCombustConCarga($combustConCarga)
    {
        $this->combustConCarga = $combustConCarga;

        return $this;
    }

    /**
     * Get combustConCarga
     *
     * @return float
     */
    public function getCombustConCarga()
    {
        return $this->combustConCarga;
    }

    /**
     * Set gee
     *
     * @param \SigigeeBundle\Entity\ExistenciaGee $gee
     *
     * @return CertifOperacion
     */
    public function setGee(ExistenciaGee $gee = null)
    {
        $this->gee = $gee;

        return $this;
    }

    /**
     * Get gee
     *
     * @return \SigigeeBundle\Entity\ExistenciaGee
     */
    public function getGee()
    {
        return $this->gee;
    }

    /**
     * Set municipio
     *
     * @param \SigigeeBundle\Entity\Municipio $municipio
     *
     * @return CertifOperacion
     */
    public function setMunicipio(Municipio $municipio = null)
    {
        $this->municipio = $municipio;

        return $this;
    }

    /**
     * Get municipio
     *
     * @return \SigigeeBundle\Entity\Municipio
     */
    public function getMunicipio()
    {
        return $this->municipio;
    }

    /**
     * Set centro
     *
     * @param \SigigeeBundle\Entity\Entidad $centro
     *
     * @return CertifOperacion
     */
    public function setCentro(Entidad $centro = null)
    {
        $this->centro = $centro;

        return $this;
    }

    /**
     * Get centro
     *
     * @return \SigigeeBundle\Entity\Entidad
     */
    public function getCentro()
    {
        return $this->centro;
    }

    /**
     * Set marca
     *
     * @param \SigigeeBundle\Entity\NomMarca $marca
     *
     * @return CertifOperacion
     */
    public function setMarca(NomMarca $marca = null)
    {
        $this->marca = $marca;

        return $this;
    }

    /**
     * Get marca
     *
     * @return \SigigeeBundle\Entity\NomMarca
     */
    public function getMarca()
    {
        return $this->marca;
    }

    /**
     * Set kvaVoltajeSalida
     *
     * @param \SigigeeBundle\Entity\NomVoltaje $kvaVoltajeSalida
     *
     * @return CertifOperacion
     */
    public function setKvaVoltajeSalida(NomVoltaje $kvaVoltajeSalida = null)
    {
        $this->kvaVoltajeSalida = $kvaVoltajeSalida;

        return $this;
    }

    /**
     * Get kvaVoltajeSalida
     *
     * @return \SigigeeBundle\Entity\NomVoltaje
     */
    public function getKvaVoltajeSalida()
    {
        return $this->kvaVoltajeSalida;
    }

    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return CertifOperacion
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }

    /**
     * Set mes
     *
     * @param integer $mes
     *
     * @return CertifOperacion
     */
    public function setMes($mes)
    {
        $this->mes = $mes;

        return $this;
    }

    /**
     * Get mes
     *
     * @return integer
     */
    public function getMes()
    {
        return $this->mes;
    }

    /**
     * Set anno
     *
     * @param integer $anno
     *
     * @return CertifOperacion
     */
    public function setAnno($anno)
    {
        $this->anno = $anno;

        return $this;
    }

    /**
     * Get anno
     *
     * @return integer
     */
    public function getAnno()
    {
        return $this->anno;
    }

    /**
     * Set estadoCertificacion
     *
     * @param \SigigeeBundle\Entity\EstadoCertificacion $estadoCertificacion
     *
     * @return CertifOperacion
     */
    public function setEstadoCertificacion(EstadoCertificacion $estadoCertificacion = null)
    {
        $this->estadoCertificacion = $estadoCertificacion;

        return $this;
    }

    /**
     * Get estadoCertificacion
     *
     * @return \SigigeeBundle\Entity\EstadoCertificacion
     */
    public function getEstadoCertificacion()
    {
        return $this->estadoCertificacion;
    }
}
