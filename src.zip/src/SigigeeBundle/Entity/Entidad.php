<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 08/09/16
 * Time: 10:02 AM
 */

namespace SigigeeBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Entidad
 *
 * @ORM\Table(name="entidad")
 * @ORM\Entity
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */

class Entidad
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     * @ORM\Column(name="nombre", type="string", length=255)
     */
    private $nombre;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomMoneda")
     */
    private $moneda;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @ORM\OneToOne(targetEntity="Entidad")
     */
    private $entidadSuperior;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Ministerio", inversedBy="entidades")
     */
    private $ministerio;

    /**
     * @var string
     * @ORM\Column(name="direccion", type="string", length=255)
     */
    private $direccion;


    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Provincia", inversedBy="entidades")
     */
    private $provincia;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Municipio", inversedBy="entidades")
     */
    private $municipio;

    /**
     * @ORM\OneToOne(targetEntity="SigigeeBundle\Entity\SolicCombLlenadoInicial", mappedBy="destinoFinal")
     */
    private $solicLlenadoInicial;

    /**
     * @ORM\OneToMany(targetEntity="SigigeeBundle\Entity\ExistenciaGee", mappedBy="entidad", cascade={"remove"})
     */
    private $geeAsignados;





    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nombre
     *
     * @param string $nombre
     * @return Entidad
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * Get nombre
     *
     * @return string
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Set entidadSuperior
     *
     * @param \SigigeeBundle\Entity\Entidad $entidadSuperior
     * @return Entidad
     */
    public function setEntidadSuperior(Entidad $entidadSuperior = null)
    {
        $this->entidadSuperior = $entidadSuperior;

        return $this;
    }

    /**
     * Get entidadSuperior
     *
     * @return \SigigeeBundle\Entity\Entidad
     */
    public function getEntidadSuperior()
    {
        return $this->entidadSuperior;
    }

    /**
     * Set provincia
     *
     * @param \SigigeeBundle\Entity\Provincia $provincia
     * @return Entidad
     */
    public function setProvincia(Provincia $provincia = null)
    {
        $this->provincia = $provincia;

        return $this;
    }

    /**
     * Get provincia
     *
     * @return \SigigeeBundle\Entity\Provincia
     */
    public function getProvincia()
    {
        return $this->provincia;
    }

    /**
     * Set municipio
     *
     * @param \SigigeeBundle\Entity\Municipio $municipio
     * @return Entidad
     */
    public function setMunicipio(Municipio $municipio = null)
    {
        $this->municipio = $municipio;

        return $this;
    }

    /**
     * Get municipio
     *
     * @return \SigigeeBundle\Entity\Municipio
     */
    public function getMunicipio()
    {
        return $this->municipio;
    }

    /**
     * Set direccion
     *
     * @param string $direccion
     * @return Entidad
     */
    public function setDireccion($direccion)
    {
        $this->direccion = $direccion;

        return $this;
    }

    /**
     * Get direccion
     *
     * @return string
     */
    public function getDireccion()
    {
        return $this->direccion;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->geeAsignados = new ArrayCollection();

    }

    /**
     * Add geeAsignados
     *
     * @param \SigigeeBundle\Entity\ExistenciaGee $geeAsignados
     * @return Entidad
     */
    public function addGeeAsignado(ExistenciaGee $geeAsignados)
    {
        $this->geeAsignados[] = $geeAsignados;

        return $this;
    }

    /**
     * Remove geeAsignados
     *
     * @param \SigigeeBundle\Entity\ExistenciaGee $geeAsignados
     */
    public function removeGeeAsignado(ExistenciaGee $geeAsignados)
    {
        $this->geeAsignados->removeElement($geeAsignados);
    }

    /**
     * Get geeAsignados
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getGeeAsignados()
    {
        return $this->geeAsignados;
    }

    /**
     * Set ministerio
     *
     * @param \SigigeeBundle\Entity\Ministerio $ministerio
     * @return Entidad
     */
    public function setMinisterio(Ministerio $ministerio = null)
    {
        $this->ministerio = $ministerio;

        return $this;
    }

    /**
     * Get ministerio
     *
     * @return \SigigeeBundle\Entity\Ministerio
     */
    public function getMinisterio()
    {
        return $this->ministerio;
    }

    public function __toString()
    {
        return $this->nombre;
    }

    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return Entidad
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }

    /**
     * Set solicLlenadoInicial
     *
     * @param SolicCombLlenadoInicial $solicLlenadoInicial
     *
     * @return Entidad
     */
    public function setSolicLlenadoInicial(SolicCombLlenadoInicial $solicLlenadoInicial = null)
    {
        $this->solicLlenadoInicial = $solicLlenadoInicial;

        return $this;
    }

    /**
     * Get solicLlenadoInicial
     *
     * @return SolicCombLlenadoInicial
     */
    public function getSolicLlenadoInicial()
    {
        return $this->solicLlenadoInicial;
    }

    /**
     * Set moneda
     *
     * @param \SigigeeBundle\Entity\NomMoneda $moneda
     *
     * @return Entidad
     */
    public function setMoneda(\SigigeeBundle\Entity\NomMoneda $moneda = null)
    {
        $this->moneda = $moneda;

        return $this;
    }

    /**
     * Get moneda
     *
     * @return \SigigeeBundle\Entity\NomMoneda
     */
    public function getMoneda()
    {
        return $this->moneda;
    }
}
