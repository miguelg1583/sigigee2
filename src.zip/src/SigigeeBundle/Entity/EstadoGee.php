<?php

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * EstadoGee
 *
 * @ORM\Table(name="estado_gee")
 * @ORM\Entity(repositoryClass="SigigeeBundle\Repository\EstadoGeeRepository")
 */
class EstadoGee
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nombre", type="string", length=255, unique=true)
     */
    private $nombre;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nombre
     *
     * @param string $nombre
     *
     * @return EstadoGee
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * Get nombre
     *
     * @return string
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    function __toString()
    {
        return $this->nombre;
    }


}
