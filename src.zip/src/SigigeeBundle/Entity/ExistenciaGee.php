<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 08/09/16
 * Time: 10:09 AM
 */

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Bridge\Doctrine\Validator\Constraints as DoctrineAssert;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * ExistenciaGee
 *
 * @ORM\Table()
 * @ORM\Entity
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class ExistenciaGee
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="noInventario", type="string", length=255, unique=true)
     */
    private $noInventario;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="fechaEntrada", type="date")
     */
    private $fechaEntrada;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomGee")
     */
    private $tipoGee;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Entidad", inversedBy="geeAsignados")
     */
    private $entidad;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\TipoDistribucion")
     */
    private $distribucion;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\EstadoGee")
     */
    private $estado;

    /**
     * @var bool
     *
     * @ORM\Column(name="instrumentos", type="boolean")
     */
    private $instrumentos;

    /**
     * @var float
     *
     * @ORM\Column(name="indice_carga", type="float", nullable=true)
     */
    private $indiceCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="indice_sin_carga", type="float", nullable=true)
     */
    private $indiceSinCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="tanque_propio", type="float", nullable=true)
     */
    private $tanquePropio;

    /**
     * @var float
     *
     * @ORM\Column(name="tanque_aux", type="float", nullable=true)
     */
    private $tanqueAux;

    /**
     * @var float
     *
     * @ORM\Column(name="cant_comb", type="float", nullable=true)
     */
    private $cantComb;

    /**
     * @var float
     *
     * @ORM\Column(name="cobertura_horas", type="float", nullable=true)
     */
    private $coberturaHoras;

    /**
     * @ORM\OneToMany(targetEntity="SigigeeBundle\Entity\RegistroOperacion", mappedBy="gee", cascade={"remove"})
     */
    private $operaciones;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set noInventario
     *
     * @param string $noInventario
     * @return ExistenciaGee
     */
    public function setNoInventario($noInventario)
    {
        $this->noInventario = $noInventario;

        return $this;
    }

    /**
     * Get noInventario
     *
     * @return string
     */
    public function getNoInventario()
    {
        return $this->noInventario;
    }

    /**
     * Set fechaEntrada
     *
     * @param \DateTime $fechaEntrada
     * @return ExistenciaGee
     */
    public function setFechaEntrada($fechaEntrada)
    {
        $this->fechaEntrada = $fechaEntrada;

        return $this;
    }

    /**
     * Get fechaEntrada
     *
     * @return \DateTime
     */
    public function getFechaEntrada()
    {
        return $this->fechaEntrada;
    }

    /**
     * Set entidad
     *
     * @param \SigigeeBundle\Entity\Entidad $entidad
     * @return ExistenciaGee
     */
    public function setEntidad(Entidad $entidad = null)
    {
        $this->entidad = $entidad;

        return $this;
    }

    /**
     * Get entidad
     *
     * @return \SigigeeBundle\Entity\Entidad
     */
    public function getEntidad()
    {
        return $this->entidad;
    }

    /**
     * Set tipoGee
     *
     * @param \SigigeeBundle\Entity\NomGee $tipoGee
     * @return ExistenciaGee
     */
    public function setTipoGee(NomGee $tipoGee = null)
    {
        $this->tipoGee = $tipoGee;

        return $this;
    }

    /**
     * Get tipoGee
     *
     * @return \SigigeeBundle\Entity\NomGee
     */
    public function getTipoGee()
    {
        return $this->tipoGee;
    }


    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return ExistenciaGee
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }

    /**
     * Set estado
     *
     * @param \SigigeeBundle\Entity\EstadoGee $estado
     *
     * @return ExistenciaGee
     */
    public function setEstado(EstadoGee $estado = null)
    {
        $this->estado = $estado;

        return $this;
    }

    /**
     * Get estado
     *
     * @return \SigigeeBundle\Entity\EstadoGee
     */
    public function getEstado()
    {
        return $this->estado;
    }

    function __toString()
    {
        return $this->noInventario;
    }

    /**
     * Set indiceCarga
     *
     * @param float $indiceCarga
     *
     * @return ExistenciaGee
     */
    public function setIndiceCarga($indiceCarga)
    {
        $this->indiceCarga = $indiceCarga;

        return $this;
    }

    /**
     * Get indiceCarga
     *
     * @return float
     */
    public function getIndiceCarga()
    {
        return $this->indiceCarga;
    }

    /**
     * Set indiceSinCarga
     *
     * @param float $indiceSinCarga
     *
     * @return ExistenciaGee
     */
    public function setIndiceSinCarga($indiceSinCarga)
    {
        $this->indiceSinCarga = $indiceSinCarga;

        return $this;
    }

    /**
     * Get indiceSinCarga
     *
     * @return float
     */
    public function getIndiceSinCarga()
    {
        return $this->indiceSinCarga;
    }

    /**
     * Set cantComb
     *
     * @param float $cantComb
     *
     * @return ExistenciaGee
     */
    public function setCantComb($cantComb)
    {
        $this->cantComb = $cantComb;

        return $this;
    }

    /**
     * Get cantComb
     *
     * @return float
     */
    public function getCantComb()
    {
        return $this->cantComb;
    }

    /**
     * Set coberturaHoras
     *
     * @param float $coberturaHoras
     *
     * @return ExistenciaGee
     */
    public function setCoberturaHoras($coberturaHoras)
    {
        $this->coberturaHoras = $coberturaHoras;

        return $this;
    }

    /**
     * Get coberturaHoras
     *
     * @return float
     */
    public function getCoberturaHoras()
    {
        return $this->coberturaHoras;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->operaciones = new ArrayCollection();
    }

    /**
     * Add operacione
     *
     * @param \SigigeeBundle\Entity\RegistroOperacion $operacione
     *
     * @return ExistenciaGee
     */
    public function addOperacione(RegistroOperacion $operacione)
    {
        $this->operaciones[] = $operacione;

        return $this;
    }

    /**
     * Remove operacione
     *
     * @param \SigigeeBundle\Entity\RegistroOperacion $operacione
     */
    public function removeOperacione(RegistroOperacion $operacione)
    {
        $this->operaciones->removeElement($operacione);
    }

    /**
     * Get operaciones
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getOperaciones()
    {
        return $this->operaciones;
    }

    /**
     * Set distribucion
     *
     * @param TipoDistribucion $distribucion
     *
     * @return ExistenciaGee
     */
    public function setDistribucion(TipoDistribucion $distribucion = null)
    {
        $this->distribucion = $distribucion;

        return $this;
    }

    /**
     * Get distribucion
     *
     * @return TipoDistribucion
     */
    public function getDistribucion()
    {
        return $this->distribucion;
    }

    /**
     * Set instrumentos
     *
     * @param boolean $instrumentos
     *
     * @return ExistenciaGee
     */
    public function setInstrumentos($instrumentos)
    {
        $this->instrumentos = $instrumentos;

        return $this;
    }

    /**
     * Get instrumentos
     *
     * @return bool
     */
    public function getInstrumentos()
    {
        return $this->instrumentos;
    }

    /**
     * Set tanquePropio
     *
     * @param float $tanquePropio
     *
     * @return ExistenciaGee
     */
    public function setTanquePropio($tanquePropio)
    {
        $this->tanquePropio = $tanquePropio;

        return $this;
    }

    /**
     * Get tanquePropio
     *
     * @return float
     */
    public function getTanquePropio()
    {
        return $this->tanquePropio;
    }

    /**
     * Set tanqueAux
     *
     * @param float $tanqueAux
     *
     * @return ExistenciaGee
     */
    public function setTanqueAux($tanqueAux)
    {
        $this->tanqueAux = $tanqueAux;

        return $this;
    }

    /**
     * Get tanqueAux
     *
     * @return float
     */
    public function getTanqueAux()
    {
        return $this->tanqueAux;
    }
}
