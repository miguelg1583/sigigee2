<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 08/09/16
 * Time: 10:18 AM
 */

namespace SigigeeBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Municipio
 *
 * @ORM\Table(name="municipio")
 * @ORM\Entity
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class Municipio
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nombre", type="string", length=255)
     */
    private $nombre;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @ORM\ManyToOne(targetEntity="Provincia", inversedBy="municipios")
     */
    private $provincia;

    /**
     * @ORM\OneToMany(targetEntity="Entidad", mappedBy="municipio")
     */
    private $entidades;

    /**
     * @return mixed
     */
    public function getProvincia()
    {
        return $this->provincia;
    }

    /**
     * @param Provincia $provincia
     */
    public function setProvincia(Provincia $provincia=null)
    {
        $this->provincia = $provincia;
    }


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nombre
     *
     * @param string $nombre
     * @return Municipio
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * Get nombre
     *
     * @return string
     */
    public function getNombre()
    {
        return $this->nombre;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->entidades = new ArrayCollection();
    }

    /**
     * Add entidades
     *
     * @param \SigigeeBundle\Entity\Entidad $entidades
     * @return Municipio
     */
    public function addEntidade(Entidad $entidades)
    {
        $this->entidades[] = $entidades;

        return $this;
    }

    /**
     * Remove entidades
     *
     * @param \SigigeeBundle\Entity\Entidad $entidades
     */
    public function removeEntidade(Entidad $entidades)
    {
        $this->entidades->removeElement($entidades);
    }

    /**
     * Get entidades
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getEntidades()
    {
        return $this->entidades;
    }

    public function __toString()
    {
        return $this->nombre ?: 'Sin Datos';
    }

    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return Municipio
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }
}
