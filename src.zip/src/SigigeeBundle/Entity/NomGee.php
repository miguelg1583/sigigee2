<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 08/09/16
 * Time: 10:23 AM
 */

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * NomGee
 *
 * @ORM\Table()
 * @ORM\Entity
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class NomGee
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="modelo", type="string", length=255)
     */
    private $modelo;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var float
     *
     * @ORM\Column(name="corrienteSalida", type="float")
     */
    private $corrienteSalida;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomUnidadMedida")
     */
    private $corrienteSalidaUM;

    /**
     * @var float
     *
     * @ORM\Column(name="potenciaSalida", type="float")
     */
    private $potenciaSalida;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomUnidadMedida")
     */
    private $potenciaSalidaUM;

    /**
     * @var float
     *
     * @ORM\Column(name="largo", type="float")
     */
    private $largo;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomUnidadMedida")
     */
    private $largoUM;

    /**
     * @var float
     *
     * @ORM\Column(name="ancho", type="float")
     */
    private $ancho;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomUnidadMedida")
     */
    private $anchoUM;

    /**
     * @var float
     *
     * @ORM\Column(name="alto", type="float")
     */
    private $alto;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomUnidadMedida")
     */
    private $altoUM;

    /**
     * @var float
     *
     * @ORM\Column(name="peso", type="float")
     */
    private $peso;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomUnidadMedida")
     */
    private $pesoUM;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomMarca")
     */
    private $marca;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomMotor")
     */
    private $motor;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomGenerador")
     */
    private $generador;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomVoltaje")
     */
    private $voltajeSalida;


//    private $corrienteSalidaUM_junto;
//
//    /**
//     * @return mixed
//     */
//    public function getCorrienteSalidaUMJunto()
//    {
//
//    }



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set modelo
     *
     * @param string $modelo
     * @return NomGee
     */
    public function setModelo($modelo)
    {
        $this->modelo = $modelo;

        return $this;
    }

    /**
     * Get modelo
     *
     * @return string
     */
    public function getModelo()
    {
        return $this->modelo;
    }

    /**
     * Set corrienteSalida
     *
     * @param float $corrienteSalida
     * @return NomGee
     */
    public function setCorrienteSalida($corrienteSalida)
    {
        $this->corrienteSalida = $corrienteSalida;

        return $this;
    }

    /**
     * Get corrienteSalida
     *
     * @return string
     */
    public function getCorrienteSalida()
    {
        return $this->corrienteSalida;
    }

    /**
     * Set potenciaSalida
     *
     * @param float $potenciaSalida
     * @return NomGee
     */
    public function setPotenciaSalida($potenciaSalida)
    {
        $this->potenciaSalida = $potenciaSalida;

        return $this;
    }

    /**
     * Get potenciaSalida
     *
     * @return float
     */
    public function getPotenciaSalida()
    {
        return $this->potenciaSalida;
    }

    /**
     * Set largo
     *
     * @param float $largo
     * @return NomGee
     */
    public function setLargo($largo)
    {
        $this->largo = $largo;

        return $this;
    }

    /**
     * Get largo
     *
     * @return float
     */
    public function getLargo()
    {
        return $this->largo;
    }

    /**
     * Set ancho
     *
     * @param float $ancho
     * @return NomGee
     */
    public function setAncho($ancho)
    {
        $this->ancho = $ancho;

        return $this;
    }

    /**
     * Get ancho
     *
     * @return float
     */
    public function getAncho()
    {
        return $this->ancho;
    }

    /**
     * Set alto
     *
     * @param float $alto
     * @return NomGee
     */
    public function setAlto($alto)
    {
        $this->alto = $alto;

        return $this;
    }

    /**
     * Get alto
     *
     * @return float
     */
    public function getAlto()
    {
        return $this->alto;
    }

    /**
     * Set peso
     *
     * @param float $peso
     * @return NomGee
     */
    public function setPeso($peso)
    {
        $this->peso = $peso;

        return $this;
    }

    /**
     * Get peso
     *
     * @return float
     */
    public function getPeso()
    {
        return $this->peso;
    }

    /**
     * Set corrienteSalidaUM
     *
     * @param \SigigeeBundle\Entity\NomUnidadMedida $corrienteSalidaUM
     * @return NomGee
     */
    public function setCorrienteSalidaUM(NomUnidadMedida $corrienteSalidaUM = null)
    {
        $this->corrienteSalidaUM = $corrienteSalidaUM;

        return $this;
    }

    /**
     * Get corrienteSalidaUM
     *
     * @return \SigigeeBundle\Entity\NomUnidadMedida
     */
    public function getCorrienteSalidaUM()
    {
        return $this->corrienteSalidaUM;
    }

    /**
     * Set potenciaSalidaUM
     *
     * @param \SigigeeBundle\Entity\NomUnidadMedida $potenciaSalidaUM
     * @return NomGee
     */
    public function setPotenciaSalidaUM(NomUnidadMedida $potenciaSalidaUM = null)
    {
        $this->potenciaSalidaUM = $potenciaSalidaUM;

        return $this;
    }

    /**
     * Get potenciaSalidaUM
     *
     * @return \SigigeeBundle\Entity\NomUnidadMedida
     */
    public function getPotenciaSalidaUM()
    {
        return $this->potenciaSalidaUM;
    }

    /**
     * Set largoUM
     *
     * @param \SigigeeBundle\Entity\NomUnidadMedida $largoUM
     * @return NomGee
     */
    public function setLargoUM(NomUnidadMedida $largoUM = null)
    {
        $this->largoUM = $largoUM;

        return $this;
    }

    /**
     * Get largoUM
     *
     * @return \SigigeeBundle\Entity\NomUnidadMedida
     */
    public function getLargoUM()
    {
        return $this->largoUM;
    }

    /**
     * Set anchoUM
     *
     * @param \SigigeeBundle\Entity\NomUnidadMedida $anchoUM
     * @return NomGee
     */
    public function setAnchoUM(NomUnidadMedida $anchoUM = null)
    {
        $this->anchoUM = $anchoUM;

        return $this;
    }

    /**
     * Get anchoUM
     *
     * @return \SigigeeBundle\Entity\NomUnidadMedida
     */
    public function getAnchoUM()
    {
        return $this->anchoUM;
    }

    /**
     * Set altoUM
     *
     * @param \SigigeeBundle\Entity\NomUnidadMedida $altoUM
     * @return NomGee
     */
    public function setAltoUM(NomUnidadMedida $altoUM = null)
    {
        $this->altoUM = $altoUM;

        return $this;
    }

    /**
     * Get altoUM
     *
     * @return \SigigeeBundle\Entity\NomUnidadMedida
     */
    public function getAltoUM()
    {
        return $this->altoUM;
    }

    /**
     * Set pesoUM
     *
     * @param \SigigeeBundle\Entity\NomUnidadMedida $pesoUM
     * @return NomGee
     */
    public function setPesoUM(NomUnidadMedida $pesoUM = null)
    {
        $this->pesoUM = $pesoUM;

        return $this;
    }

    /**
     * Get pesoUM
     *
     * @return \SigigeeBundle\Entity\NomUnidadMedida
     */
    public function getPesoUM()
    {
        return $this->pesoUM;
    }

    /**
     * Set marca
     *
     * @param \SigigeeBundle\Entity\NomMarca $marca
     * @return NomGee
     */
    public function setMarca(NomMarca $marca = null)
    {
        $this->marca = $marca;

        return $this;
    }

    /**
     * Get marca
     *
     * @return \SigigeeBundle\Entity\NomMarca
     */
    public function getMarca()
    {
        return $this->marca;
    }

    /**
     * Set motor
     *
     * @param \SigigeeBundle\Entity\NomMotor $motor
     * @return NomGee
     */
    public function setMotor(NomMotor $motor = null)
    {
        $this->motor = $motor;

        return $this;
    }

    /**
     * Get motor
     *
     * @return \SigigeeBundle\Entity\NomMotor
     */
    public function getMotor()
    {
        return $this->motor;
    }

    /**
     * Set generador
     *
     * @param \SigigeeBundle\Entity\NomGenerador $generador
     * @return NomGee
     */
    public function setGenerador(NomGenerador $generador = null)
    {
        $this->generador = $generador;

        return $this;
    }

    /**
     * Get generador
     *
     * @return \SigigeeBundle\Entity\NomGenerador
     */
    public function getGenerador()
    {
        return $this->generador;
    }

    /**
     * Set voltajeSalida
     *
     * @param \SigigeeBundle\Entity\NomVoltaje $voltajeSalida
     * @return NomGee
     */
    public function setVoltajeSalida(NomVoltaje $voltajeSalida = null)
    {
        $this->voltajeSalida = $voltajeSalida;

        return $this;
    }

    /**
     * Get voltajeSalida
     *
     * @return \SigigeeBundle\Entity\NomVoltaje
     */
    public function getVoltajeSalida()
    {
        return $this->voltajeSalida;
    }

    function __toString()
    {
        return $this->modelo." ".$this->marca." ".$this->voltajeSalida;
    }

    public function getCorrienteConUM()
    {
        return (string)$this->getCorrienteSalida()." ".$this->getCorrienteSalidaUM();
    }

    public function getPotenciaConUm()
    {
        return (string)$this->getPotenciaSalida()." ".$this->getPotenciaSalidaUM();
    }

    public function getLargoConUM()
    {
        return (string)$this->getLargo()." ".$this->getLargoUM();
    }

    public function getAnchoConUM()
    {
        return (string)$this->getAncho()." ".$this->getAnchoUM();
    }

    public function getAltoConUM()
    {
        return (string)$this->getAlto()." ".$this->getAltoUM();
    }

    public function getPesoConUM()
    {
        return (string)$this->getPeso()." ".$this->getPesoUM();
    }

    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return NomGee
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }
}
