<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 08/09/16
 * Time: 10:27 AM
 */


namespace SigigeeBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
/**
 * NomMotor
 *
 * @ORM\Table(name="nom_motor")
 * @ORM\Entity
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */

class NomMotor
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nombre", type="string", length=255)
     */
    private $nombre;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var string
     *
     * @ORM\Column(name="modelo", type="string", length=255)
     */
    private $modelo;

    /**
     * @var integer
     *
     * @ORM\Column(name="rpm", type="integer")
     */
    private $rpm;

    /**
     * @var integer
     *
     * @ORM\Column(name="voltaje", type="integer")
     */
    private $voltaje;

    /**
     * @var integer
     *
     * @ORM\Column(name="cant_baterias", type="integer")
     */
    private $cantBaterias;

    /**
     * @var string
     *
     * @ORM\Column(name="aceite", type="string", length=255)
     */
    private $aceite;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nombre
     *
     * @param string $nombre
     * @return NomMotor
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * Get nombre
     *
     * @return string
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Set modelo
     *
     * @param string $modelo
     * @return NomMotor
     */
    public function setModelo($modelo)
    {
        $this->modelo = $modelo;

        return $this;
    }

    /**
     * Get modelo
     *
     * @return string
     */
    public function getModelo()
    {
        return $this->modelo;
    }

    /**
     * Set rpm
     *
     * @param integer $rpm
     * @return NomMotor
     */
    public function setRpm($rpm)
    {
        $this->rpm = $rpm;

        return $this;
    }

    /**
     * Get rpm
     *
     * @return integer
     */
    public function getRpm()
    {
        return $this->rpm;
    }

    /**
     * Set voltaje
     *
     * @param integer $voltaje
     * @return NomMotor
     */
    public function setVoltaje($voltaje)
    {
        $this->voltaje = $voltaje;

        return $this;
    }

    /**
     * Get voltaje
     *
     * @return integer
     */
    public function getVoltaje()
    {
        return $this->voltaje;
    }

    /**
     * Set cantBaterias
     *
     * @param integer $cantBaterias
     * @return NomMotor
     */
    public function setCantBaterias($cantBaterias)
    {
        $this->cantBaterias = $cantBaterias;

        return $this;
    }

    /**
     * Get cantBaterias
     *
     * @return integer
     */
    public function getCantBaterias()
    {
        return $this->cantBaterias;
    }

    /**
     * Set aceite
     *
     * @param string $aceite
     * @return NomMotor
     */
    public function setAceite($aceite)
    {
        $this->aceite = $aceite;

        return $this;
    }

    /**
     * Get aceite
     *
     * @return string
     */
    public function getAceite()
    {
        return $this->aceite;
    }
    function __toString()
    {
        // TODO: Implement __toString() method.
        return $this->nombre." ".$this->modelo;
    }

    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return NomMotor
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }
}
