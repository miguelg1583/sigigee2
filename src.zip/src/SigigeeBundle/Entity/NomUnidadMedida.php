<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 08/09/16
 * Time: 10:34 AM
 */

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * NomUnidadMedida
 *
 * @ORM\Table()
 * @ORM\Entity
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class NomUnidadMedida
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="notacion", type="string", length=255)
     */
    private $notacion;

    /**
     * @var string
     *
     * @ORM\Column(name="descripcion", type="string", length=255)
     */
    private $descripcion;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set notacion
     *
     * @param string $notacion
     * @return NomUnidadMedida
     */
    public function setNotacion($notacion)
    {
        $this->notacion = $notacion;

        return $this;
    }

    /**
     * Get notacion
     *
     * @return string
     */
    public function getNotacion()
    {
        return $this->notacion;
    }

    /**
     * Set descripcion
     *
     * @param string $descripcion
     * @return NomUnidadMedida
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    /**
     * Get descripcion
     *
     * @return string
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    function __toString()
    {
        // TODO: Implement __toString() method.
        return $this->notacion;
    }



    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return NomUnidadMedida
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }
}
