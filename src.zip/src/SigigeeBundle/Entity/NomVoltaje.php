<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 08/09/16
 * Time: 10:35 AM
 */

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * NomVoltaje
 *
 * @ORM\Table()
 * @ORM\Entity
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class NomVoltaje
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="voltaje", type="string", length=255)
     */
    private $voltaje;

    /**
     * @var string
     *
     * @ORM\Column(name="corriente", type="string", length=255)
     */
    private $corriente;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomUnidadMedida")
     */
    private $unidadMedida;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set voltaje
     *
     * @param string $voltaje
     * @return NomVoltaje
     */
    public function setVoltaje($voltaje)
    {
        $this->voltaje = $voltaje;

        return $this;
    }

    /**
     * Get voltaje
     *
     * @return string
     */
    public function getVoltaje()
    {
        return $this->voltaje;
    }

    /**
     * Set corriente
     *
     * @param string $corriente
     * @return NomVoltaje
     */
    public function setCorriente($corriente)
    {
        $this->corriente = $corriente;

        return $this;
    }

    /**
     * Get corriente
     *
     * @return string
     */
    public function getCorriente()
    {
        return $this->corriente;
    }

    /**
     * Set unidadMedida
     *
     * @param \SigigeeBundle\Entity\NomUnidadMedida $unidadMedida
     * @return NomVoltaje
     */
    public function setUnidadMedida(NomUnidadMedida $unidadMedida = null)
    {
        $this->unidadMedida = $unidadMedida;

        return $this;
    }

    /**
     * Get unidadMedida
     *
     * @return \SigigeeBundle\Entity\NomUnidadMedida
     */
    public function getUnidadMedida()
    {
        return $this->unidadMedida;
    }

    function __toString()
    {
        // TODO: Implement __toString() method.
        return $this->voltaje." V";
    }

    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return NomVoltaje
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }
}
