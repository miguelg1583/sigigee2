<?php

namespace SigigeeBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Provincia
 *
 * @ORM\Table(name="provincia")
 * @ORM\Entity(repositoryClass="SigigeeBundle\Repository\ProvinciaRepository")
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class Provincia
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nombre", type="string", length=255)
     */
    private $nombre;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @ORM\OneToMany(targetEntity="Municipio", mappedBy="provincia")
     */
    private $municipios;


    /**
     * @ORM\OneToMany(targetEntity="Entidad", mappedBy="provincia")
     */
    private $entidades;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nombre
     *
     * @param string $nombre
     * @return Provincia
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * Get nombre
     *
     * @return string
     */
    public function getNombre()
    {
        return $this->nombre;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->municipios = new ArrayCollection();
        $this->entidades = new ArrayCollection();
    }

    /**
     * Add municipios
     *
     * @param \SigigeeBundle\Entity\Municipio $municipios
     * @return Provincia
     */
    public function addMunicipio(Municipio $municipios)
    {
        $this->municipios[] = $municipios;

        return $this;
    }

    /**
     * Remove municipios
     *
     * @param \SigigeeBundle\Entity\Municipio $municipios
     */
    public function removeMunicipio(Municipio $municipios)
    {
        $this->municipios->removeElement($municipios);
    }

    /**
     * Get municipios
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getMunicipios()
    {
        return $this->municipios;
    }

    /**
     * Add entidades
     *
     * @param \SigigeeBundle\Entity\Entidad $entidades
     * @return Provincia
     */
    public function addEntidades(Entidad $entidades)
    {
        $this->entidades[] = $entidades;

        return $this;
    }

    /**
     * Remove entidades
     *
     * @param \SigigeeBundle\Entity\Entidad $entidades
     */
    public function removeEntidade(Entidad $entidades)
    {
        $this->entidades->removeElement($entidades);
    }

    /**
     * Get entidades
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getEntidades()
    {
        return $this->entidades;
    }

    /**
     * Add entidades
     *
     * @param \SigigeeBundle\Entity\Entidad $entidades
     * @return Provincia
     */
    public function addEntidade(Entidad $entidades)
    {
        $this->entidades[] = $entidades;

        return $this;
    }

    public function __toString()
    {
        return $this->nombre ?: 'Sin Datos';
    }

    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return Provincia
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }
}
