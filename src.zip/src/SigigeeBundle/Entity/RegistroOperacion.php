<?php

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * RegistroOperacion
 *
 * @ORM\Table(name="registro_operacion")
 * @ORM\Entity(repositoryClass="SigigeeBundle\Repository\RegistroOperacionRepository")
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class RegistroOperacion
{
    function __toString()
    {
        return $this->getId().' '.$this->getGee().' '.$this->getGee()->getEntidad();
    }

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dia", type="date")
     */
    private $dia;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\ExistenciaGee", inversedBy="operaciones")
     */
    private $gee;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\TipoOperacion")
     */
    private $tipo;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="horaInicial", type="time", nullable=true)
     */
    private $horaInicial;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="horaFinal", type="time", nullable=true)
     */
    private $horaFinal;

    /**
     * @var float
     *
     * @ORM\Column(name="horametroInicial", type="float", nullable=true)
     */
    private $horametroInicial;

    /**
     * @var float
     *
     * @ORM\Column(name="horametroFinal", type="float", nullable=true)
     */
    private $horametroFinal;

    /**
     * @var float
     *
     * @ORM\Column(name="tiempoTrabajado", type="float", nullable=true)
     */
    private $tiempoTrabajado;

    /**
     * @var float
     *
     * @ORM\Column(name="demandaLiberada", type="float", nullable=true)
     */
    private $demandaLiberada;

    /**
     * @var float
     *
     * @ORM\Column(name="energiaGenerada", type="float", nullable=true)
     */
    private $energiaGenerada;

    /**
     * @var float
     *
     * @ORM\Column(name="combustibleConsumido", type="float", nullable=true)
     */
    private $combustibleConsumido;

    /**
     * @var float
     *
     * @ORM\Column(name="combustibleExistencia", type="float", nullable=true)
     */
    private $combustibleExistencia;

    /**
     * @var string
     *
     * @ORM\Column(name="observaciones", type="string", length=255, nullable=true)
     */
    private $observaciones;

    /**
     * @var string
     *
     * @ORM\Column(name="quienReporta", type="string", length=255, nullable=true)
     */
    private $quienReporta;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\EstadoOperacion")
     */
    private $estadoOperacion;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set dia
     *
     * @param \DateTime $dia
     *
     * @return RegistroOperacion
     */
    public function setDia($dia)
    {
        $this->dia = $dia;

        return $this;
    }

    /**
     * Get dia
     *
     * @return \DateTime
     */
    public function getDia()
    {
        return $this->dia;
    }

    /**
     * Set tipo
     *
     * @param \SigigeeBundle\Entity\TipoOperacion $tipo
     *
     * @return RegistroOperacion
     */
    public function setTipo($tipo)
    {
        $this->tipo = $tipo;

        return $this;
    }

    /**
     * Get tipo
     *
     * @return \SigigeeBundle\Entity\TipoOperacion
     */
    public function getTipo()
    {
        return $this->tipo;
    }

    /**
     * Set horaInicial
     *
     * @param \DateTime $horaInicial
     *
     * @return RegistroOperacion
     */
    public function setHoraInicial($horaInicial)
    {
        $this->horaInicial = $horaInicial;

        return $this;
    }

    /**
     * Get horaInicial
     *
     * @return \DateTime
     */
    public function getHoraInicial()
    {
        return $this->horaInicial;
    }

    /**
     * Set horaFinal
     *
     * @param \DateTime $horaFinal
     *
     * @return RegistroOperacion
     */
    public function setHoraFinal($horaFinal)
    {
        $this->horaFinal = $horaFinal;

        return $this;
    }

    /**
     * Get horaFinal
     *
     * @return \DateTime
     */
    public function getHoraFinal()
    {
        return $this->horaFinal;
    }

    /**
     * Set horametroInicial
     *
     * @param float $horametroInicial
     *
     * @return RegistroOperacion
     */
    public function setHorametroInicial($horametroInicial)
    {
        $this->horametroInicial = $horametroInicial;

        return $this;
    }

    /**
     * Get horametroInicial
     *
     * @return float
     */
    public function getHorametroInicial()
    {
        return $this->horametroInicial;
    }

    /**
     * Set horametroFinal
     *
     * @param float $horametroFinal
     *
     * @return RegistroOperacion
     */
    public function setHorametroFinal($horametroFinal)
    {
        $this->horametroFinal = $horametroFinal;

        return $this;
    }

    /**
     * Get horametroFinal
     *
     * @return float
     */
    public function getHorametroFinal()
    {
        return $this->horametroFinal;
    }

    /**
     * Set tiempoTrabajado
     *
     * @param float $tiempoTrabajado
     *
     * @return RegistroOperacion
     */
    public function setTiempoTrabajado($tiempoTrabajado)
    {
        $this->tiempoTrabajado = $tiempoTrabajado;

        return $this;
    }

    /**
     * Get tiempoTrabajado
     *
     * @return float
     */
    public function getTiempoTrabajado()
    {
        return $this->tiempoTrabajado;
    }

    /**
     * Set demandaLiberada
     *
     * @param float $demandaLiberada
     *
     * @return RegistroOperacion
     */
    public function setDemandaLiberada($demandaLiberada)
    {
        $this->demandaLiberada = $demandaLiberada;

        return $this;
    }

    /**
     * Get demandaLiberada
     *
     * @return float
     */
    public function getDemandaLiberada()
    {
        return $this->demandaLiberada;
    }

    /**
     * Set energiaGenerada
     *
     * @param float $energiaGenerada
     *
     * @return RegistroOperacion
     */
    public function setEnergiaGenerada($energiaGenerada)
    {
        $this->energiaGenerada = $energiaGenerada;

        return $this;
    }

    /**
     * Get energiaGenerada
     *
     * @return float
     */
    public function getEnergiaGenerada()
    {
        return $this->energiaGenerada;
    }

    /**
     * Set combustibleConsumido
     *
     * @param float $combustibleConsumido
     *
     * @return RegistroOperacion
     */
    public function setCombustibleConsumido($combustibleConsumido)
    {
        $this->combustibleConsumido = $combustibleConsumido;

        return $this;
    }

    /**
     * Get combustibleConsumido
     *
     * @return float
     */
    public function getCombustibleConsumido()
    {
        return $this->combustibleConsumido;
    }

    /**
     * Set combustibleExistencia
     *
     * @param float $combustibleExistencia
     *
     * @return RegistroOperacion
     */
    public function setCombustibleExistencia($combustibleExistencia)
    {
        $this->combustibleExistencia = $combustibleExistencia;

        return $this;
    }

    /**
     * Get combustibleExistencia
     *
     * @return float
     */
    public function getCombustibleExistencia()
    {
        return $this->combustibleExistencia;
    }

    /**
     * Set observaciones
     *
     * @param string $observaciones
     *
     * @return RegistroOperacion
     */
    public function setObservaciones($observaciones)
    {
        $this->observaciones = $observaciones;

        return $this;
    }

    /**
     * Get observaciones
     *
     * @return string
     */
    public function getObservaciones()
    {
        return $this->observaciones;
    }

    /**
     * Set quienReporta
     *
     * @param string $quienReporta
     *
     * @return RegistroOperacion
     */
    public function setQuienReporta($quienReporta)
    {
        $this->quienReporta = $quienReporta;

        return $this;
    }

    /**
     * Get quienReporta
     *
     * @return string
     */
    public function getQuienReporta()
    {
        return $this->quienReporta;
    }

    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return RegistroOperacion
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }

    /**
     * Set gee
     *
     * @param \SigigeeBundle\Entity\ExistenciaGee $gee
     *
     * @return RegistroOperacion
     */
    public function setGee(ExistenciaGee $gee = null)
    {
        $this->gee = $gee;

        return $this;
    }

    /**
     * Get gee
     *
     * @return \SigigeeBundle\Entity\ExistenciaGee
     */
    public function getGee()
    {
        return $this->gee;
    }

    /**
     * Set estadoOperacion
     *
     * @param \SigigeeBundle\Entity\EstadoOperacion $estadoOperacion
     *
     * @return RegistroOperacion
     */
    public function setEstadoOperacion(EstadoOperacion $estadoOperacion = null)
    {
        $this->estadoOperacion = $estadoOperacion;

        return $this;
    }

    /**
     * Get estadoOperacion
     *
     * @return \SigigeeBundle\Entity\EstadoOperacion
     */
    public function getEstadoOperacion()
    {
        return $this->estadoOperacion;
    }
}
