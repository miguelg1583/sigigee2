<?php

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ResumenCertificacion
 *
 * @ORM\Table(name="resumen_certificacion")
 * @ORM\Entity(repositoryClass="SigigeeBundle\Repository\ResumenCertificacionRepository")
 */
class ResumenCertificacion
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\ExistenciaGee")
     */
    private $gee;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Municipio")
     */
    private $municipio;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Entidad")
     */
    private $centro;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\NomMarca")
     */
    private $marca;

    /**
     * @var int
     *
     * @ORM\Column(name="mes", type="integer")
     */
    private $mes;

    /**
     * @var int
     *
     * @ORM\Column(name="anno", type="integer")
     */
    private $anno;

    /**
     * @var int
     *
     * @ORM\Column(name="operacSinCarga", type="integer", nullable=true)
     */
    private $operacSinCarga;

    /**
     * @var int
     *
     * @ORM\Column(name="operacCarga", type="integer", nullable=true)
     */
    private $operacCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="horasSinCarga", type="float", nullable=true)
     */
    private $horasSinCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="horasCarga", type="float", nullable=true)
     */
    private $horasCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="energiaGenerada", type="float", nullable=true)
     */
    private $energiaGenerada;

    /**
     * @var float
     *
     * @ORM\Column(name="combustSinCarga", type="float", nullable=true)
     */
    private $combustSinCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="combustCarga", type="float", nullable=true)
     */
    private $combustCarga;

    /**
     * @var float
     *
     * @ORM\Column(name="combustTotal", type="float", nullable=true)
     */
    private $combustTotal;

    function __toString()
    {
        return $this->getGee().' '.$this->getMes().' '.$this->getAnno().' '.$this->getCombustTotal();
    }


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set mes
     *
     * @param integer $mes
     *
     * @return ResumenCertificacion
     */
    public function setMes($mes)
    {
        $this->mes = $mes;

        return $this;
    }

    /**
     * Get mes
     *
     * @return int
     */
    public function getMes()
    {
        return $this->mes;
    }

    /**
     * Set anno
     *
     * @param integer $anno
     *
     * @return ResumenCertificacion
     */
    public function setAnno($anno)
    {
        $this->anno = $anno;

        return $this;
    }

    /**
     * Get anno
     *
     * @return int
     */
    public function getAnno()
    {
        return $this->anno;
    }

    /**
     * Set operacSinCarga
     *
     * @param integer $operacSinCarga
     *
     * @return ResumenCertificacion
     */
    public function setOperacSinCarga($operacSinCarga)
    {
        $this->operacSinCarga = $operacSinCarga;

        return $this;
    }

    /**
     * Get operacSinCarga
     *
     * @return int
     */
    public function getOperacSinCarga()
    {
        return $this->operacSinCarga;
    }

    /**
     * Set operacCarga
     *
     * @param integer $operacCarga
     *
     * @return ResumenCertificacion
     */
    public function setOperacCarga($operacCarga)
    {
        $this->operacCarga = $operacCarga;

        return $this;
    }

    /**
     * Get operacCarga
     *
     * @return int
     */
    public function getOperacCarga()
    {
        return $this->operacCarga;
    }

    /**
     * Set horasSinCarga
     *
     * @param float $horasSinCarga
     *
     * @return ResumenCertificacion
     */
    public function setHorasSinCarga($horasSinCarga)
    {
        $this->horasSinCarga = $horasSinCarga;

        return $this;
    }

    /**
     * Get horasSinCarga
     *
     * @return float
     */
    public function getHorasSinCarga()
    {
        return $this->horasSinCarga;
    }

    /**
     * Set horasCarga
     *
     * @param float $horasCarga
     *
     * @return ResumenCertificacion
     */
    public function setHorasCarga($horasCarga)
    {
        $this->horasCarga = $horasCarga;

        return $this;
    }

    /**
     * Get horasCarga
     *
     * @return float
     */
    public function getHorasCarga()
    {
        return $this->horasCarga;
    }

    /**
     * Set energiaGenerada
     *
     * @param float $energiaGenerada
     *
     * @return ResumenCertificacion
     */
    public function setEnergiaGenerada($energiaGenerada)
    {
        $this->energiaGenerada = $energiaGenerada;

        return $this;
    }

    /**
     * Get energiaGenerada
     *
     * @return float
     */
    public function getEnergiaGenerada()
    {
        return $this->energiaGenerada;
    }

    /**
     * Set combustSinCarga
     *
     * @param float $combustSinCarga
     *
     * @return ResumenCertificacion
     */
    public function setCombustSinCarga($combustSinCarga)
    {
        $this->combustSinCarga = $combustSinCarga;

        return $this;
    }

    /**
     * Get combustSinCarga
     *
     * @return float
     */
    public function getCombustSinCarga()
    {
        return $this->combustSinCarga;
    }

    /**
     * Set combustCarga
     *
     * @param float $combustCarga
     *
     * @return ResumenCertificacion
     */
    public function setCombustCarga($combustCarga)
    {
        $this->combustCarga = $combustCarga;

        return $this;
    }

    /**
     * Get combustCarga
     *
     * @return float
     */
    public function getCombustCarga()
    {
        return $this->combustCarga;
    }

    /**
     * Set combustTotal
     *
     * @param float $combustTotal
     *
     * @return ResumenCertificacion
     */
    public function setCombustTotal($combustTotal)
    {
        $this->combustTotal = $combustTotal;

        return $this;
    }

    /**
     * Get combustTotal
     *
     * @return float
     */
    public function getCombustTotal()
    {
        return $this->combustTotal;
    }

    /**
     * Set gee
     *
     * @param \SigigeeBundle\Entity\ExistenciaGee $gee
     *
     * @return ResumenCertificacion
     */
    public function setGee(\SigigeeBundle\Entity\ExistenciaGee $gee = null)
    {
        $this->gee = $gee;

        return $this;
    }

    /**
     * Get gee
     *
     * @return \SigigeeBundle\Entity\ExistenciaGee
     */
    public function getGee()
    {
        return $this->gee;
    }

    /**
     * Set municipio
     *
     * @param \SigigeeBundle\Entity\Municipio $municipio
     *
     * @return ResumenCertificacion
     */
    public function setMunicipio(\SigigeeBundle\Entity\Municipio $municipio = null)
    {
        $this->municipio = $municipio;

        return $this;
    }

    /**
     * Get municipio
     *
     * @return \SigigeeBundle\Entity\Municipio
     */
    public function getMunicipio()
    {
        return $this->municipio;
    }

    /**
     * Set centro
     *
     * @param \SigigeeBundle\Entity\Entidad $centro
     *
     * @return ResumenCertificacion
     */
    public function setCentro(\SigigeeBundle\Entity\Entidad $centro = null)
    {
        $this->centro = $centro;

        return $this;
    }

    /**
     * Get centro
     *
     * @return \SigigeeBundle\Entity\Entidad
     */
    public function getCentro()
    {
        return $this->centro;
    }

    /**
     * Set marca
     *
     * @param \SigigeeBundle\Entity\NomMarca $marca
     *
     * @return ResumenCertificacion
     */
    public function setMarca(\SigigeeBundle\Entity\NomMarca $marca = null)
    {
        $this->marca = $marca;

        return $this;
    }

    /**
     * Get marca
     *
     * @return \SigigeeBundle\Entity\NomMarca
     */
    public function getMarca()
    {
        return $this->marca;
    }
}
