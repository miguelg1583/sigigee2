<?php

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;



/**
 * SolicCombLlenadoInicial
 *
 * @ORM\Table(name="solic_comb_llenado_inicial")
 * @ORM\Entity(repositoryClass="SigigeeBundle\Repository\SolicCombLlenadoInicialRepository")
 * @Gedmo\SoftDeleteable(fieldName="deletedAt", timeAware=false)
 */
class SolicCombLlenadoInicial
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\Column(name="deleted_at", type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="fechaSolicitud", type="date")
     */
    private $fechaSolicitud;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="fechaAprobacion", type="date", nullable=true)
     */
    private $fechaAprobacion;

    /**
     * @var string
     *
     * @ORM\Column(name="descripcion", type="string", length=255, nullable=true)
     */
    private $descripcion;

    /**
     * @var int
     *
     * @ORM\Column(name="noCartaAprobacion", type="integer", nullable=true)
     */
    private $noCartaAprobacion;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\EstadoAprobacion")
     */
    private $aprobado;


    /**
     * @var float
     *
     * @ORM\Column(name="cantidad", type="float")
     */
    private $cantidad;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\TipoDistribucion")
     */
    private $distribucion;

    /**
     * @ORM\ManyToOne(targetEntity="SigigeeBundle\Entity\Entidad", inversedBy="solicLlenadoInicial")
     */
    private $destinoFinal;

    /**
     * @ORM\OneToOne(targetEntity="SigigeeBundle\Entity\ExistenciaGee")
     */
    private $gee;

    /**
     * @var string
     *
     * @ORM\Column(name="observaciones", type="string", length=255, nullable=true)
     */
    private $observaciones;

    /**
     * @var int
     *
     * @ORM\Column(name="noOrdenDistribucion", type="integer", nullable=true)
     */
    private $noOrdenDistribucion;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fechaSolicitud
     *
     * @param \DateTime $fechaSolicitud
     *
     * @return SolicCombLlenadoInicial
     */
    public function setFechaSolicitud($fechaSolicitud)
    {
        $this->fechaSolicitud = $fechaSolicitud;

        return $this;
    }

    /**
     * Get fechaSolicitud
     *
     * @return \DateTime
     */
    public function getFechaSolicitud()
    {
        return $this->fechaSolicitud;
    }

    /**
     * Set fechaAprobacion
     *
     * @param \DateTime $fechaAprobacion
     *
     * @return SolicCombLlenadoInicial
     */
    public function setFechaAprobacion($fechaAprobacion)
    {
        $this->fechaAprobacion = $fechaAprobacion;

        return $this;
    }

    /**
     * Get fechaAprobacion
     *
     * @return \DateTime
     */
    public function getFechaAprobacion()
    {
        return $this->fechaAprobacion;
    }

    /**
     * Set descripcion
     *
     * @param string $descripcion
     *
     * @return SolicCombLlenadoInicial
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    /**
     * Get descripcion
     *
     * @return string
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * Set noCartaAprobacion
     *
     * @param integer $noCartaAprobacion
     *
     * @return SolicCombLlenadoInicial
     */
    public function setNoCartaAprobacion($noCartaAprobacion)
    {
        $this->noCartaAprobacion = $noCartaAprobacion;

        return $this;
    }

    /**
     * Get noCartaAprobacion
     *
     * @return int
     */
    public function getNoCartaAprobacion()
    {
        return $this->noCartaAprobacion;
    }

    /**
     * Set cantidad
     *
     * @param string $cantidad
     *
     * @return SolicCombLlenadoInicial
     */
    public function setCantidad($cantidad)
    {
        $this->cantidad = $cantidad;

        return $this;
    }

    /**
     * Get cantidad
     *
     * @return float
     */
    public function getCantidad()
    {
        return $this->cantidad;
    }

    /**
     * Set observaciones
     *
     * @param string $observaciones
     *
     * @return SolicCombLlenadoInicial
     */
    public function setObservaciones($observaciones)
    {
        $this->observaciones = $observaciones;

        return $this;
    }

    /**
     * Get observaciones
     *
     * @return string
     */
    public function getObservaciones()
    {
        return $this->observaciones;
    }

    /**
     * Set noOrdenDistribucion
     *
     * @param integer $noOrdenDistribucion
     *
     * @return SolicCombLlenadoInicial
     */
    public function setNoOrdenDistribucion($noOrdenDistribucion)
    {
        $this->noOrdenDistribucion = $noOrdenDistribucion;

        return $this;
    }

    /**
     * Get noOrdenDistribucion
     *
     * @return int
     */
    public function getNoOrdenDistribucion()
    {
        return $this->noOrdenDistribucion;
    }

    /**
     * Set aprobado
     *
     * @param EstadoAprobacion $aprobado
     *
     * @return SolicCombLlenadoInicial
     */
    public function setAprobado(EstadoAprobacion $aprobado = null)
    {
        $this->aprobado = $aprobado;

        return $this;
    }

    /**
     * Get aprobado
     *
     * @return EstadoAprobacion
     */
    public function getAprobado()
    {
        return $this->aprobado;
    }

    /**
     * Set distribucion
     *
     * @param TipoDistribucion $distribucion
     *
     * @return SolicCombLlenadoInicial
     */
    public function setDistribucion(TipoDistribucion $distribucion = null)
    {
        $this->distribucion = $distribucion;

        return $this;
    }

        /**
     * Get distribucion
     *
     * @return TipoDistribucion
     */
    public function getDistribucion()
    {
        return $this->distribucion;
    }

    /**
     * Set destinoFinal
     *
     * @param Entidad $destinoFinal
     *
     * @return SolicCombLlenadoInicial
     */
    public function setDestinoFinal(Entidad $destinoFinal = null)
    {
        $this->destinoFinal = $destinoFinal;

        return $this;
    }

    /**
     * Get destinoFinal
     *
     * @return Entidad
     */
    public function getDestinoFinal()
    {
        return $this->destinoFinal;
    }

    function __toString()
    {
        if(is_null($this->getDestinoFinal()))
        {
            return $this->getId()." ".$this->getFechaSolicitud()->format('d/m/Y') ?:'Sin Datos';
        }
        return (string)($this->getCantidad())." ".$this->getDestinoFinal()->getNombre() ?:'Sin Datos';
    }



    /**
     * Set gee
     *
     * @param \SigigeeBundle\Entity\ExistenciaGee $gee
     *
     * @return SolicCombLlenadoInicial
     */
    public function setGee(ExistenciaGee $gee = null)
    {
        $this->gee = $gee;

        return $this;
    }

    /**
     * Get gee
     *
     * @return \SigigeeBundle\Entity\ExistenciaGee
     */
    public function getGee()
    {
        return $this->gee;
    }

    /**
     * Set deletedAt
     *
     * @param \DateTime $deletedAt
     *
     * @return SolicCombLlenadoInicial
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return \DateTime
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }
}
