<?php

namespace SigigeeBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Traza
 *
 * @ORM\Table(name="traza")
 * @ORM\Entity(repositoryClass="SigigeeBundle\Repository\TrazaRepository")
 */
class Traza
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="usuario", type="string", length=255, nullable=true)
     */
    private $usuario;

//    /**
//     * @var int
//     *
//     * @ORM\Column(name="idUsuario", type="integer", nullable=true)
//     */
//    private $idUsuario;

    /**
     * @var string
     *
     * @ORM\Column(name="tabla", type="string", length=255)
     */
    private $tabla;

    /**
     * @var string
     *
     * @ORM\Column(name="registro", type="string", length=255, nullable=true)
     */
    private $registro;

    /**
     * @var string
     *
     * @ORM\Column(name="ip", type="string", length=255, nullable=true)
     */
    private $ip;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="fecha", type="date", nullable=true)
     */
    private $fecha;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="hora", type="time", nullable=true)
     */
    private $hora;

    /**
     * @var string
     *
     * @ORM\Column(name="accion", type="string", length=255, nullable=true)
     */
    private $accion;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set usuario
     *
     * @param string $usuario
     *
     * @return Traza
     */
    public function setUsuario($usuario)
    {
        $this->usuario = $usuario;

        return $this;
    }

    /**
     * Get usuario
     *
     * @return string
     */
    public function getUsuario()
    {
        return $this->usuario;
    }

//    /**
//     * Set idUsuario
//     *
//     * @param integer $idUsuario
//     *
//     * @return Traza
//     */
//    public function setIdUsuario($idUsuario)
//    {
//        $this->idUsuario = $idUsuario;
//
//        return $this;
//    }
//
//    /**
//     * Get idUsuario
//     *
//     * @return int
//     */
//    public function getIdUsuario()
//    {
//        return $this->idUsuario;
//    }

    /**
     * Set tabla
     *
     * @param string $tabla
     *
     * @return Traza
     */
    public function setTabla($tabla)
    {
        $this->tabla = $tabla;

        return $this;
    }

    /**
     * Get tabla
     *
     * @return string
     */
    public function getTabla()
    {
        return $this->tabla;
    }

    /**
     * Set registro
     *
     * @param string $registro
     *
     * @return Traza
     */
    public function setRegistro($registro)
    {
        $this->registro = $registro;

        return $this;
    }

    /**
     * Get registro
     *
     * @return string
     */
    public function getRegistro()
    {
        return $this->registro;
    }

    /**
     * Set ip
     *
     * @param string $ip
     *
     * @return Traza
     */
    public function setIp($ip)
    {
        $this->ip = $ip;

        return $this;
    }

    /**
     * Get ip
     *
     * @return string
     */
    public function getIp()
    {
        return $this->ip;
    }

    /**
     * Set fecha
     *
     * @param \DateTime $fecha
     *
     * @return Traza
     */
    public function setFecha($fecha)
    {
        $this->fecha = $fecha;

        return $this;
    }

    /**
     * Get fecha
     *
     * @return \DateTime
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * Set hora
     *
     * @param \DateTime $hora
     *
     * @return Traza
     */
    public function setHora($hora)
    {
        $this->hora = $hora;

        return $this;
    }

    /**
     * Get hora
     *
     * @return \DateTime
     */
    public function getHora()
    {
        return $this->hora;
    }

    /**
     * Set accion
     *
     * @param string $accion
     *
     * @return Traza
     */
    public function setAccion($accion)
    {
        $this->accion = $accion;

        return $this;
    }

    /**
     * Get accion
     *
     * @return string
     */
    public function getAccion()
    {
        return $this->accion;
    }
}
