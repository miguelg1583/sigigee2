<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 18/02/17
 * Time: 02:26 AM
 */

namespace SigigeeBundle\Listener;

use Doctrine\ORM\Event\LifecycleEventArgs;
use SigigeeBundle\Entity\AsignacionComb;
use SigigeeBundle\Entity\ExistenciaGee;

class AprobInicialListener
{
    public function postPersist(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $em = $args->getEntityManager();
        if($entity instanceof AsignacionComb)
        {
            $existGee=$em->getRepository("SigigeeBundle:ExistenciaGee")->find($entity->getGee()->getId());
            $existGee->setCantComb(round(($entity->getCombustible()),2));
            $em->flush();
        }
        if($entity instanceof ExistenciaGee)
        {
            $entity->setCoberturaHoras(round(($entity->getCantComb()/$entity->getIndiceCarga()),2)?:0);

            if($entity->getCoberturaHoras()>=48)
            {
                $entity->setEstado($em->getRepository("SigigeeBundle:EstadoGee")->findOneBy(array('nombre'=>'Óptimo')));
            }
            elseif($entity->getCoberturaHoras()<48 and $entity->getCoberturaHoras()>=24)
            {
                $entity->setEstado($em->getRepository("SigigeeBundle:EstadoGee")->findOneBy(array('nombre'=>'Baja Cobertura')));
            }
            elseif($entity->getCoberturaHoras()<24 and $entity->getCoberturaHoras()>0)
            {
                $entity->setEstado($em->getRepository("SigigeeBundle:EstadoGee")->findOneBy(array('nombre'=>'Nivel Crítico')));
            }
            else
            {
                $entity->setEstado($em->getRepository("SigigeeBundle:EstadoGee")->findOneBy(array('nombre'=>'Sin Combustible')));
            }
            $em->flush();
        }
    }

    public function preUpdate(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $em = $args->getEntityManager();
        if($entity instanceof AsignacionComb)
        {
            $existGee=$em->getRepository("SigigeeBundle:ExistenciaGee")->find($entity->getGee()->getId());
            $existGee->setCantComb(($existGee->getCantComb()-$entity->getCombustible())?:0);
            $em->flush();
        }
    }

    public function postUpdate(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $em = $args->getEntityManager();
        if($entity instanceof AsignacionComb)
        {
            $existGee=$em->getRepository("SigigeeBundle:ExistenciaGee")->find($entity->getGee()->getId());
            $existGee->setCantComb(round(($entity->getCombustible()),2));
            $em->flush();
        }
        if($entity instanceof ExistenciaGee)
        {
            $entity->setCoberturaHoras(round(($entity->getCantComb()/$entity->getIndiceCarga()),2)?:0);

            if($entity->getCoberturaHoras()>=48)
            {
                $entity->setEstado($em->getRepository("SigigeeBundle:EstadoGee")->findOneBy(array('nombre'=>'Óptimo')));
            }
            elseif($entity->getCoberturaHoras()<48 and $entity->getCoberturaHoras()>=24)
            {
                $entity->setEstado($em->getRepository("SigigeeBundle:EstadoGee")->findOneBy(array('nombre'=>'Baja Cobertura')));
            }
            elseif($entity->getCoberturaHoras()<24 and $entity->getCoberturaHoras()>0)
            {
                $entity->setEstado($em->getRepository("SigigeeBundle:EstadoGee")->findOneBy(array('nombre'=>'Nivel Crítico')));
            }
            else
            {
                $entity->setEstado($em->getRepository("SigigeeBundle:EstadoGee")->findOneBy(array('nombre'=>'Sin Combustible')));
            }
            $em->flush();
        }
    }



}