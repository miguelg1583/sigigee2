<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 17/02/17
 * Time: 09:56 PM
 */

namespace SigigeeBundle\Listener;

use Doctrine\ORM\Event\LifecycleEventArgs;
use SigigeeBundle\Entity\AsignacionComb;
use SigigeeBundle\Entity\CertifOperacion;

class CertifCombListener
{
    public function postPersist(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $entityManager = $args->getEntityManager();
        if($entity instanceof CertifOperacion){
            $asignacionComb=new AsignacionComb();

            $aprovpend=$entityManager->getRepository("SigigeeBundle:EstadoAprobacion")->findOneBy(array('nombre'=>'Pendiente'));
            $conceptoOperacion=$entityManager->getRepository("SigigeeBundle:ConceptoAprobComb")->findOneBy(array('nombre'=>'Por Operaciones'));
            $asignacionComb
                ->setProvincia($entity->getCentro()->getProvincia())
                ->setEntidad($entity->getCentro())
                ->setGee($entity->getGee())
                ->setFechaSolic($entity->getFechaSolicitud())
                ->setCombustible($entity->getCantidad()*1188.78)    //ver conversion de ton a litros
                ->setEstadoAprob($aprovpend)
                ->setConcepto($conceptoOperacion)
                ->setTipoDistribucion($entity->getDistribucion());
            $entityManager->persist($asignacionComb);
            $entityManager->flush();
        }
    }

    public function postUpdate(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $entityManager = $args->getEntityManager();
        if($entity instanceof CertifOperacion){
            $conceptoInicial=$entityManager->getRepository("SigigeeBundle:ConceptoAprobComb")->findOneBy(array('nombre'=>'Llenado Inicial'));
            $asignacionComb=$entityManager->getRepository("SigigeeBundle:AsignacionComb")->findOneBy(array('entidad'=>$entity->getDestinoFinal(), 'concepto'=>$conceptoInicial, 'deletedAt'=>''));

//            $aprovpend=$entityManager->getRepository("SigigeeBundle:EstadoAprobacion")->findOneBy(array('nombre'=>'Pendiente'));
            if(!is_null($asignacionComb)){
                $asignacionComb
                    ->setProvincia($entity->getDestinoFinal()->getProvincia())
                    ->setEntidad($entity->getDestinoFinal())
//                 ->setGee($entity->get)
                    ->setFechaSolic($entity->getFechaSolicitud())
                    ->setCombustible($entity->getCantidad()*1188.78)    //ver conversion de ton a litros
//                 ->setEstadoAprob($aprovpend)
//                 ->setConcepto($conceptoInicial)
                    ->setTipoDistribucion($entity->getDistribucion());
//             $entityManager->persist($asignacionComb);
                $entityManager->flush();}
        }
    }

    public function preRemove(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $entityManager = $args->getEntityManager();
        if($entity instanceof CertifOperacion){
            $conceptoInicial=$entityManager->getRepository("SigigeeBundle:ConceptoAprobComb")->findOneBy(array('nombre'=>'Llenado Inicial'));
            $asignacionComb=$entityManager->getRepository("SigigeeBundle:AsignacionComb")->findOneBy(array('entidad'=>$entity->getDestinoFinal(), 'concepto'=>$conceptoInicial));

            if(!is_null($asignacionComb)){
                $entityManager->remove($asignacionComb);
                $entityManager->flush();}
        }
    }

}