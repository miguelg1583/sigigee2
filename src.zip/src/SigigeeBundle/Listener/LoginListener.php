<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 10/01/17
 * Time: 11:34 PM
 */

namespace SigigeeBundle\Listener;

use Symfony\Component\Security\Http\Event\InteractiveLoginEvent;
use Symfony\Component\DependencyInjection\ContainerInterface;
use SigigeeBundle\Entity\Traza;

class LoginListener
{
    protected $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function onSecurityInteractiveLogin(InteractiveLoginEvent $event)
    {
// capturamos el usuario logueado
        $usuario= $event->getAuthenticationToken()->getUser();
        $traza = new Traza(); // creamos una nueva entidad
        $traza->setUsuario($usuario); // nombre del usuario
//        $traza->setIdUsuario($usuario->getId());
        $traza->setIp($this->container->get('request')->getClientIp());
        $traza->setFecha(new \DateTime('today'));
        $traza->setHora(new \DateTime('now'));
        $traza->setAccion("LogIn");
        $traza->setTabla("Sistema");
        $traza->setRegistro("Login exitoso");
        $em = $this->container->get('doctrine')->getManager();
        $em->persist($traza);
        $em->flush();
    }
}