<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 11/01/17
 * Time: 12:04 AM
 */

namespace SigigeeBundle\Listener;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Http\Logout\LogoutSuccessHandlerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;
use SigigeeBundle\Entity\Traza;

class LogoutListener implements LogoutSuccessHandlerInterface
{
    protected $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }
    /**
     * Creates a Response object to send upon a successful logout.
     *
     * @param Request $request
     *
     * @return Response never null
     */
    public function onLogoutSuccess(Request $request)
    {

//        throw new \Exception(__METHOD__);


        $usuario= $this->container->get('security.token_storage')->getToken()->getUser();
//        $usuario = $this->container->get('')
        $traza = new Traza();
        $traza->setUsuario($usuario);
//        $traza->setIdUsuario($usuario->getId());
        $traza->setIp($request->getClientIp());
        $traza->setFecha(new \DateTime('today'));
        $traza->setHora(new \DateTime('now'));
        $traza->setAccion("LogOut");
        $traza->setTabla("Sistema");
        $traza->setRegistro("LogOut exitoso");
        $em = $this->container->get('doctrine')->getManager();
        $em->persist($traza);
        $em->flush();

        return new RedirectResponse($this->container->get('router')->generate('sonata_user_admin_security_login', array()));
    }
}