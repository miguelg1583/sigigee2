<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 16/02/17
 * Time: 10:24 AM
 */

namespace SigigeeBundle\Listener;

use Doctrine\ORM\Event\LifecycleEventArgs;
use SigigeeBundle\Entity\AsignacionComb;
//use SigigeeBundle\Entity\Provincia;
use SigigeeBundle\Entity\SolicCombLlenadoInicial;


class SolicInicialListener
{
    public function postPersist(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $em = $args->getEntityManager();
        if($entity instanceof SolicCombLlenadoInicial){
            if($entity->getAprobado()==$em->getRepository("SigigeeBundle:EstadoAprobacion")->findOneBy(array('nombre'=>'Si')) and !is_null($entity->getFechaAprobacion()))
            {
                $asignacionComb=new AsignacionComb();
                $asignacionComb
                    ->setProvincia($entity->getDestinoFinal()->getProvincia())
                    ->setEntidad($entity->getDestinoFinal())
                    ->setGee($entity->getGee())
                    ->setTipoDistribucion($entity->getDistribucion())
                    ->setCombustible($entity->getCantidad()*1188.78)    //ver conversion de ton a litros
                    ->setFechaSolic($entity->getFechaSolicitud())
                ;
                $em->persist($asignacionComb);
                $em->flush();
            }
//            private $id;
//            private $provincia;
//            private $entidad;
//            private $gee;
//            private $tipoDistribucion;
//            private $combustible;
//            private $fechaSolic;
        }
    }

    public function postUpdate(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $em = $args->getEntityManager();
        if($entity instanceof SolicCombLlenadoInicial){
            if($entity->getAprobado()==$em->getRepository("SigigeeBundle:EstadoAprobacion")->findOneBy(array('nombre'=>'Si')) and !is_null($entity->getFechaAprobacion()))
            {
                $asignaciones=$em->getRepository("SigigeeBundle:AsignacionComb")->findOneBy(array('entidad'=>$entity->getDestinoFinal(), 'gee'=>$entity->getGee()));
                if(!$asignaciones)
                {
                    $asignacionComb=new AsignacionComb();
                    $asignacionComb
                        ->setProvincia($entity->getDestinoFinal()->getProvincia())
                        ->setEntidad($entity->getDestinoFinal())
                        ->setGee($entity->getGee())
                        ->setTipoDistribucion($entity->getDistribucion())
                        ->setCombustible($entity->getCantidad()*1188.78)    //ver conversion de ton a litros
                        ->setFechaSolic($entity->getFechaSolicitud())
                    ;
                    $em->persist($asignacionComb);
                    $em->flush();
                }
                else
                {
                    $asignaciones
                        ->setCombustible($entity->getCantidad()*1188.78)    //ver conversion de ton a litros
                        ->setFechaSolic($entity->getFechaSolicitud())
                    ;
                    $em->flush();
                }

            }
        }
    }

    public function preRemove(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $em = $args->getEntityManager();
        if($entity instanceof SolicCombLlenadoInicial){
            $asignaciones=$em->getRepository("SigigeeBundle:AsignacionComb")->findOneBy(array('entidad'=>$entity->getDestinoFinal(), 'gee'=>$entity->getGee()));
            if($asignaciones)
            {
                $em->remove($asignaciones);
                $em->flush();
            }

//            $conceptoInicial=$entityManager->getRepository("SigigeeBundle:ConceptoAprobComb")->findOneBy(array('nombre'=>'Llenado Inicial'));
//            $asignacionComb=$entityManager->getRepository("SigigeeBundle:AsignacionComb")->findOneBy(array('entidad'=>$entity->getDestinoFinal(), 'concepto'=>$conceptoInicial));
//
//            if(!is_null($asignacionComb)){
//            $entityManager->remove($asignacionComb);
//            $entityManager->flush();}
        }
    }

}