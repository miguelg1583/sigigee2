<?php
/**
 * Created by PhpStorm.
 * User: chola
 * Date: 11/01/17
 * Time: 05:38 PM
 */

namespace SigigeeBundle\Listener;


use Doctrine\ORM\Event\LifecycleEventArgs;
use SigigeeBundle\Entity\Traza;
use Symfony\Component\DependencyInjection\ContainerInterface;

class TrazaListener
{
    protected $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function postPersist(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $entityManager = $args->getEntityManager();
        if($entity instanceof Traza == false){
            $usuario = ($this->container->get('security.token_storage')->getToken()->getUser())?:'Consola';
            $modelo_full = str_replace('Entity\\', '', get_class($entity));
            $traza = new Traza();
            $traza
                ->setUsuario($usuario)
                ->setTabla($modelo_full)
                ->setRegistro($entity)
                ->setIp($this->container->get('request')->getClientIp()?:'Consola')
                ->setFecha(new \DateTime('today'))
                ->setHora(new \DateTime('now'))
                ->setAccion("Adición");

            $entityManager->persist($traza);
            $entityManager->flush();
        }
    }

    public function postUpdate(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $entityManager = $args->getEntityManager();
        if($entity instanceof Traza == false){
            $usuario = $this->container->get('security.token_storage')->getToken()->getUser()?:'Consola';
            $modelo_full = str_replace('Entity\\', '', get_class($entity));
            $traza = new Traza();
            $traza
                ->setUsuario($usuario)
                ->setTabla($modelo_full)
                ->setRegistro($entity)
                ->setIp($this->container->get('request')->getClientIp()?:'Consola')
                ->setFecha(new \DateTime('today'))
                ->setHora(new \DateTime('now'))
                ->setAccion("Actualización");

            $entityManager->persist($traza);
            $entityManager->flush();
        }
    }

    public function preRemove(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $entityManager = $args->getEntityManager();
        if($entity instanceof Traza == false){
            $usuario = $this->container->get('security.token_storage')->getToken()->getUser()?:'Consola';
            $modelo_full = str_replace('Entity\\', '', get_class($entity));
            $traza = new Traza();
            $traza
                ->setUsuario($usuario)
                ->setTabla($modelo_full)
                ->setRegistro($entity)
                ->setIp($this->container->get('request')->getClientIp()?:'Consola')
                ->setFecha(new \DateTime('today'))
                ->setHora(new \DateTime('now'))
                ->setAccion("Eliminación");

            $entityManager->persist($traza);
            $entityManager->flush();
        }
    }

}