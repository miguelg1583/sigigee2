<?php

namespace SigigeeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;


class SigigeeBundle extends Bundle
{

}
